<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_sharegoods_module`;");
E_C("CREATE TABLE `ecs_sharegoods_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `localdomain` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ms_appid` varchar(60) DEFAULT NULL,
  `lang` varchar(10) DEFAULT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT '',
  `content` text,
  `api_data` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_sharegoods_module` values('1','taobao','http://item.taobao.com,http://item.tmall.com','','1','淘宝','AFC76A66CF4F434ED080D245C30CF1E71C22959C','','','','','a:3:{s:11:\"session_key\";s:56:\"6t4260sdl19pzptm77wv5ngu633y55q9iabm17106q197oq9r6s37wh6\";s:7:\"fun_key\";s:8:\"CDBPLFGA\";s:10:\"expires_in\";i:1455913427;}','a:22:{s:3:\"pid\";N;s:12:\"price_change\";s:0:\"\";s:8:\"not_sale\";i:0;s:9:\"not_brand\";i:0;s:8:\"only_img\";i:0;s:8:\"only_tbk\";i:0;s:8:\"is_order\";i:0;s:9:\"to_taobao\";i:0;s:6:\"get_sn\";i:0;s:8:\"not_desc\";i:0;s:7:\"get_pro\";i:0;s:6:\"biaoti\";i:1;s:5:\"jiage\";i:1;s:7:\"miaoshu\";i:1;s:5:\"zhutu\";i:1;s:7:\"xiangce\";i:1;s:9:\"xiaoliang\";i:1;s:6:\"pinpai\";i:1;s:8:\"ms_appid\";s:40:\"AFC76A66CF4F434ED080D245C30CF1E71C22959C\";s:8:\"code_tdj\";s:0:\"\";s:7:\"app_key\";s:8:\"23124193\";s:10:\"app_secret\";s:32:\"57ba5b9fb5bf775ccc5a64813cb10710\";}');");
E_D("replace into `ecs_sharegoods_module` values('2','albb','http://item.taobao.com,http://item.tmall.com','','1','淘宝','AFC76A66CF4F434ED080D245C30CF1E71C22959C','','','','','a:6:{s:7:\"app_key\";N;s:10:\"app_secret\";N;s:6:\"tk_pid\";N;s:11:\"session_key\";s:56:\"6t4260sdl19pzptm77wv5ngu633y55q9iabm17106q197oq9r6s37wh6\";s:7:\"fun_key\";s:1:\"C\";s:10:\"expires_in\";i:1449060524;}','a:22:{s:3:\"pid\";N;s:12:\"price_change\";s:0:\"\";s:8:\"not_sale\";i:0;s:9:\"not_brand\";i:0;s:8:\"only_img\";i:0;s:8:\"only_tbk\";i:0;s:8:\"is_order\";i:0;s:9:\"to_taobao\";i:0;s:6:\"get_sn\";i:0;s:8:\"not_desc\";i:0;s:7:\"get_pro\";i:0;s:11:\"priceRanges\";i:0;s:6:\"biaoti\";i:0;s:5:\"jiage\";i:0;s:7:\"miaoshu\";i:0;s:5:\"zhutu\";i:0;s:7:\"xiangce\";i:0;s:9:\"xiaoliang\";i:0;s:6:\"pinpai\";i:0;s:8:\"ms_appid\";s:40:\"AFC76A66CF4F434ED080D245C30CF1E71C22959C\";s:7:\"app_key\";s:7:\"1019341\";s:10:\"app_secret\";s:12:\"7khBu2BMvpCN\";}');");

require("../../inc/footer.php");
?>