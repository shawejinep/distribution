<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ofproperty`;");
E_C("CREATE TABLE `ofproperty` (
  `name` varchar(100) NOT NULL,
  `propValue` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `ofproperty` values('passwordKey','OlWlsLSc9P2r43d');");
E_D("replace into `ofproperty` values('xmpp.socket.ssl.active','true');");
E_D("replace into `ofproperty` values('xmpp.domain','www.taotao5.cn');");
E_D("replace into `ofproperty` values('provider.admin.className','org.jivesoftware.openfire.admin.DefaultAdminProvider');");
E_D("replace into `ofproperty` values('provider.lockout.className','org.jivesoftware.openfire.lockout.DefaultLockOutProvider');");
E_D("replace into `ofproperty` values('provider.user.className','org.jivesoftware.openfire.user.DefaultUserProvider');");
E_D("replace into `ofproperty` values('provider.auth.className','org.jivesoftware.openfire.auth.DefaultAuthProvider');");
E_D("replace into `ofproperty` values('xmpp.auth.anonymous','true');");
E_D("replace into `ofproperty` values('provider.group.className','org.jivesoftware.openfire.group.DefaultGroupProvider');");
E_D("replace into `ofproperty` values('provider.vcard.className','org.jivesoftware.openfire.vcard.DefaultVCardProvider');");
E_D("replace into `ofproperty` values('provider.securityAudit.className','org.jivesoftware.openfire.security.DefaultSecurityAuditProvider');");
E_D("replace into `ofproperty` values('adminConsole.port','9090');");
E_D("replace into `ofproperty` values('adminConsole.securePort','9091');");
E_D("replace into `ofproperty` values('locale','zh_CN');");
E_D("replace into `ofproperty` values('connectionProvider.className','org.jivesoftware.database.DefaultConnectionProvider');");
E_D("replace into `ofproperty` values('database.defaultProvider.driver','com.mysql.jdbc.Driver');");
E_D("replace into `ofproperty` values('database.defaultProvider.serverURL','jdbc:mysql://127.0.0.1:3306/xjdv4cs?rewriteBatchedStatements=true');");
E_D("replace into `ofproperty` values('database.defaultProvider.username','89499780b21036cf94499c6f6534bd693e13c81657dad498');");
E_D("replace into `ofproperty` values('database.defaultProvider.password','af49f727e870ce79bbb395dcdf7307ebb40632950c290b88fde7ed6819301112');");
E_D("replace into `ofproperty` values('database.defaultProvider.testSQL','select 1');");
E_D("replace into `ofproperty` values('database.defaultProvider.testBeforeUse','false');");
E_D("replace into `ofproperty` values('database.defaultProvider.testAfterUse','false');");
E_D("replace into `ofproperty` values('database.defaultProvider.minConnections','5');");
E_D("replace into `ofproperty` values('database.defaultProvider.maxConnections','25');");
E_D("replace into `ofproperty` values('database.defaultProvider.connectionTimeout','1.0');");
E_D("replace into `ofproperty` values('setup','true');");
E_D("replace into `ofproperty` values('xmpp.session.conflict-limit','0');");
E_D("replace into `ofproperty` values('update.lastCheck','1443975579309');");

require("../../inc/footer.php");
?>