<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_dianpu`;");
E_C("CREATE TABLE `ecs_dianpu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dianpu_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_dianpu` values('1','华为','13911112222','29');");
E_D("replace into `ecs_dianpu` values('4','好卖','18688525521','30');");
E_D("replace into `ecs_dianpu` values('5','哈哈哈','','33');");
E_D("replace into `ecs_dianpu` values('6','5212','12345678901','36');");
E_D("replace into `ecs_dianpu` values('7','张三点','133','14');");
E_D("replace into `ecs_dianpu` values('8','淘乐','8732776210','79');");
E_D("replace into `ecs_dianpu` values('9','天蝎座','18504156075','80');");
E_D("replace into `ecs_dianpu` values('10','1236666','13688617337','93');");
E_D("replace into `ecs_dianpu` values('13','小小小','15038681882','74');");
E_D("replace into `ecs_dianpu` values('15','123','15311111117','75');");
E_D("replace into `ecs_dianpu` values('16','test','14715025036','117');");
E_D("replace into `ecs_dianpu` values('17','CC','','130');");
E_D("replace into `ecs_dianpu` values('18','Jimmy','123455888455','128');");
E_D("replace into `ecs_dianpu` values('19','哦','1','136');");
E_D("replace into `ecs_dianpu` values('21','爱情','18147790001','134');");
E_D("replace into `ecs_dianpu` values('22','我的','12345678901','160');");
E_D("replace into `ecs_dianpu` values('23','cctq','13321999113','148');");
E_D("replace into `ecs_dianpu` values('24','锋锐','13153778108','72');");
E_D("replace into `ecs_dianpu` values('25','rrrt','','177');");
E_D("replace into `ecs_dianpu` values('27','振东店铺','17090402560','49');");
E_D("replace into `ecs_dianpu` values('28','留些','18657108965','197');");
E_D("replace into `ecs_dianpu` values('29','天随人愿的店铺','13931834399','199');");
E_D("replace into `ecs_dianpu` values('30','1','13322333322','207');");
E_D("replace into `ecs_dianpu` values('31','公共卫生保健','18984288680','214');");
E_D("replace into `ecs_dianpu` values('35','应当','18992731380','222');");
E_D("replace into `ecs_dianpu` values('34','开心天天消','15339524889','223');");

require("../../inc/footer.php");
?>