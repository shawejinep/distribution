<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_corn`;");
E_C("CREATE TABLE `ecs_weixin_corn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `sendtime` int(11) NOT NULL,
  `issend` tinyint(4) NOT NULL COMMENT '0未发送1成功2失败',
  `ecuid` int(11) NOT NULL COMMENT '系统用户ID',
  `sendtype` tinyint(1) NOT NULL COMMENT '0单人1所有',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_corn` values('1','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:33:\"发生大发范德萨发方式啊\";}}','1445777612','1445777612','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('2','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:27:\"惹我确认为亲人全文\";}}','1445777671','1445777671','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('3','a:3:{s:6:\"touser\";s:28:\"o7WUpuNYEAkgpJd-3rqENPq8orrQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:12:\"啊发顺丰\";}}','1445777770','1445777770','0','40','0');");
E_D("replace into `ecs_weixin_corn` values('4','a:3:{s:6:\"touser\";s:28:\"o7WUpuNYEAkgpJd-3rqENPq8orrQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:6:\"打发\";}}','1445777839','1445777839','0','40','0');");
E_D("replace into `ecs_weixin_corn` values('5','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:21:\"发的发阿范德萨\";}}','1445777856','1445777856','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('6','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:12:\"打算发散\";}}','1445777913','1445777913','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('7','a:3:{s:6:\"touser\";s:28:\"o7WUpuNYEAkgpJd-3rqENPq8orrQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:59:\"订单2015120704845分成，您得到的分成金额为9.48\";}}','1449418108','1449418108','2','42','1');");
E_D("replace into `ecs_weixin_corn` values('8','a:3:{s:6:\"touser\";s:28:\"o7WUpuKJ8e7yTAHdOhJXdDV3n2Ys\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:59:\"订单2015120704845分成，您得到的分成金额为4.74\";}}','1449418108','1449418108','2','41','1');");
E_D("replace into `ecs_weixin_corn` values('9','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:3:\"111\";}}','1450772245','1450772245','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('10','a:3:{s:6:\"touser\";s:28:\"o7WUpuL7ivfJqVp-bCH44C6-RSIY\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:3:\"111\";}}','1450794871','1450794871','0','31','0');");
E_D("replace into `ecs_weixin_corn` values('11','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450801115','1450801115','0','47','0');");
E_D("replace into `ecs_weixin_corn` values('12','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450801693','1450801693','0','57','0');");
E_D("replace into `ecs_weixin_corn` values('13','a:3:{s:6:\"touser\";s:28:\"oAfaAw6rxfIWoqZlrN4QSaRzAvaU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:60:\"订单2015122356148分成，您得到的分成金额为13.08\";}}','1450801925','1450801925','2','56','1');");
E_D("replace into `ecs_weixin_corn` values('14','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:9:\"大家好\";}}','1450802033','1450802033','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('15','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450803265','1450803265','0','57','0');");
E_D("replace into `ecs_weixin_corn` values('16','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450803674','1450803674','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('17','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450843445','1450843445','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('18','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450843503','1450843503','2','57','1');");
E_D("replace into `ecs_weixin_corn` values('19','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450844675','1450844675','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('20','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450844755','1450844755','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('21','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:100:\"您购买的商品（订单号：\$order_sn）已经发货请注意查收！快递号：\$shoping_code\";}}','1450845371','1450845371','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('22','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:98:\"您购买的商品（订单号：order_sn）已经发货请注意查收！快递号：shoping_code\";}}','1450845818','1450845818','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('23','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450846194','1450846194','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('24','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:98:\"您购买的商品（订单号：order_sn）已经发货请注意查收！快递号：shoping_code\";}}','1450846236','1450846236','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('25','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:98:\"您购买的商品（订单号：order_sn）已经发货请注意查收！快递号：shoping_code\";}}','1450846345','1450846345','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('26','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:98:\"您购买的商品（订单号：order_sn）已经发货请注意查收！快递号：shoping_code\";}}','1450846514','1450846514','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('27','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:92:\"您购买的商品（订单号order_sn）已经发货请注意查收！快递号shoping_code\";}}','1450846833','1450846833','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('28','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:92:\"您购买的商品（订单号order_sn）已经发货请注意查收！快递号shoping_code\";}}','1450847002','1450847002','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('29','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:88:\"11买的商品（订单号order_sn）已经发货请注意查收！快递号shoping_code\";}}','1450847018','1450847018','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('30','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:92:\"您购买的商品（订单号order_sn）已经发货请注意查收！快递号shoping_code\";}}','1450847187','1450847187','0','57','2');");
E_D("replace into `ecs_weixin_corn` values('31','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";N;}}','1450847238','1450847238','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('32','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:91:\"您购买的商品（订单号2015122304925）已经发货请注意查收！快递号111111\";}}','1450847253','1450847253','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('33','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:91:\"您购买的商品（订单号2015122304925）已经发货请注意查收！快递号111111\";}}','1450847282','1450847282','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('34','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450847914','1450847914','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('35','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450848132','1450848132','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('36','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:119:\"您购买的商品（订单号:2015122306266）已经发货请注意查收！快递公司：顺丰速运快递号:11111\";}}','1450848171','1450848171','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('37','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450848517','1450848517','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('38','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:121:\"您购买的商品（订单号:2015122347798）已经发货请注意查收！快递公司：顺丰速运快递号:1111111\";}}','1450848844','1450848844','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('39','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450849285','1450849285','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('40','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450850285','1450850285','2','57','0');");
E_D("replace into `ecs_weixin_corn` values('41','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:119:\"您购买的商品（订单号:2015122332830）已经发货请注意查收！快递公司：顺丰速运快递号:11111\";}}','1450850372','1450850372','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('42','a:3:{s:6:\"touser\";s:28:\"oAfaAw6_2dYXzQpM9a13zN3B2yyg\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:114:\"您购买的商品（订单号:2015122358465）已经发货请注意查收！快递公司：顺丰速运快递号:\";}}','1450850525','1450850525','2','57','2');");
E_D("replace into `ecs_weixin_corn` values('43','a:3:{s:6:\"touser\";s:28:\"oAfaAw_t4Rji8Y_ApXBF-fVflrhQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1450928679','1450928679','2','49','0');");
E_D("replace into `ecs_weixin_corn` values('44','a:3:{s:6:\"touser\";s:28:\"oAfaAw7r88xeoEPm5VLBHySmRW5M\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451028637','1451028637','2','74','0');");
E_D("replace into `ecs_weixin_corn` values('45','a:3:{s:6:\"touser\";s:28:\"oAfaAw9OcF4SOf0nQgJXB0jx8fgI\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451099369','1451099369','2','105','0');");
E_D("replace into `ecs_weixin_corn` values('46','a:3:{s:6:\"touser\";s:28:\"oAfaAw9OcF4SOf0nQgJXB0jx8fgI\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451099964','1451099964','2','105','0');");
E_D("replace into `ecs_weixin_corn` values('47','a:3:{s:6:\"touser\";s:28:\"oAfaAw9OcF4SOf0nQgJXB0jx8fgI\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:135:\"您购买的商品（订单号:2015122637454）已经发货请注意查收！快递公司：顺丰速运快递号:请输入快递单号\";}}','1451100047','1451100047','2','105','2');");
E_D("replace into `ecs_weixin_corn` values('48','a:3:{s:6:\"touser\";s:28:\"oAfaAw41VhD2crhBDmRo4RwcG7Xw\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451187587','1451187587','2','110','0');");
E_D("replace into `ecs_weixin_corn` values('49','a:3:{s:6:\"touser\";s:28:\"oAfaAwx5SZWXgruyFDOxKuPOVyeE\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451195350','1451195350','2','75','0');");
E_D("replace into `ecs_weixin_corn` values('50','a:3:{s:6:\"touser\";s:28:\"oAfaAwxdxU0FUK3tKiLaD6fzwYs4\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451273351','1451273351','2','113','0');");
E_D("replace into `ecs_weixin_corn` values('51','a:3:{s:6:\"touser\";s:28:\"oAfaAwxdxU0FUK3tKiLaD6fzwYs4\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451288936','1451288936','2','113','0');");
E_D("replace into `ecs_weixin_corn` values('52','a:3:{s:6:\"touser\";s:28:\"oAfaAw5E5Vsiod9YAVkfLGmTgIgo\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451290396','1451290396','2','119','0');");
E_D("replace into `ecs_weixin_corn` values('53','a:3:{s:6:\"touser\";s:28:\"oAfaAwxCkhy8-xohfC5F7B1fqarU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451292979','1451292979','2','102','0');");
E_D("replace into `ecs_weixin_corn` values('54','a:3:{s:6:\"touser\";s:28:\"oAfaAwxCkhy8-xohfC5F7B1fqarU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451293104','1451293104','2','102','0');");
E_D("replace into `ecs_weixin_corn` values('55','a:3:{s:6:\"touser\";s:28:\"oAfaAwxCkhy8-xohfC5F7B1fqarU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451293182','1451293182','2','102','0');");
E_D("replace into `ecs_weixin_corn` values('56','a:3:{s:6:\"touser\";s:28:\"oAfaAwxCkhy8-xohfC5F7B1fqarU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451293766','1451293766','2','102','0');");
E_D("replace into `ecs_weixin_corn` values('57','a:3:{s:6:\"touser\";s:28:\"oAfaAw3EtN9O0xvbB3DpLIYQzK3k\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451297133','1451297133','2','120','0');");
E_D("replace into `ecs_weixin_corn` values('58','a:3:{s:6:\"touser\";s:28:\"oAfaAw3EtN9O0xvbB3DpLIYQzK3k\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451297469','1451297469','2','120','0');");
E_D("replace into `ecs_weixin_corn` values('59','a:3:{s:6:\"touser\";s:28:\"oAfaAw3EtN9O0xvbB3DpLIYQzK3k\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:126:\"您购买的商品（订单号:2015122881446）已经发货请注意查收！快递公司：顺丰速运快递号:545454854845\";}}','1451297588','1451297588','2','120','2');");
E_D("replace into `ecs_weixin_corn` values('60','a:3:{s:6:\"touser\";s:28:\"oAfaAwwOUqgbr3-U2vOc-TtsIiYA\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451318150','1451318150','2','126','0');");
E_D("replace into `ecs_weixin_corn` values('61','a:3:{s:6:\"touser\";s:28:\"oAfaAwzT_GXDv3BT_rdk2x_YG6qo\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451357610','1451357610','2','129','0');");
E_D("replace into `ecs_weixin_corn` values('62','a:3:{s:6:\"touser\";s:28:\"oAfaAw6GIesdB-5-QZoFckzMlTUk\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451548276','1451548276','2','147','0');");
E_D("replace into `ecs_weixin_corn` values('63','a:3:{s:6:\"touser\";s:28:\"oAfaAw6GIesdB-5-QZoFckzMlTUk\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451548395','1451548395','2','147','0');");
E_D("replace into `ecs_weixin_corn` values('64','a:3:{s:6:\"touser\";s:28:\"oAfaAw6GIesdB-5-QZoFckzMlTUk\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451549026','1451549026','2','147','0');");
E_D("replace into `ecs_weixin_corn` values('65','a:3:{s:6:\"touser\";s:28:\"oAfaAw3omynL8NVxVrgWZdS0Ty2o\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451841180','1451841180','0','167','0');");
E_D("replace into `ecs_weixin_corn` values('66','a:3:{s:6:\"touser\";s:28:\"oAfaAw3omynL8NVxVrgWZdS0Ty2o\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451841217','1451841217','0','167','0');");
E_D("replace into `ecs_weixin_corn` values('67','a:3:{s:6:\"touser\";s:28:\"oAfaAwwPoAWUptjBfy5tboC7XSuQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451903744','1451903744','0','148','0');");
E_D("replace into `ecs_weixin_corn` values('68','a:3:{s:6:\"touser\";s:28:\"oAfaAwwPoAWUptjBfy5tboC7XSuQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451919278','1451919278','0','148','0');");
E_D("replace into `ecs_weixin_corn` values('69','a:3:{s:6:\"touser\";s:28:\"oAfaAwwPoAWUptjBfy5tboC7XSuQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451919406','1451919406','0','148','0');");
E_D("replace into `ecs_weixin_corn` values('70','a:3:{s:6:\"touser\";s:28:\"oAfaAwwPoAWUptjBfy5tboC7XSuQ\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1451925880','1451925880','0','148','0');");
E_D("replace into `ecs_weixin_corn` values('71','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:36:\"新功能测试，消息推送测试\";}}','1451986191','1451986191','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('72','a:3:{s:6:\"touser\";s:0:\"\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"新功能测试，消息推送\";}}','1451986450','1451986450','2','0','1');");
E_D("replace into `ecs_weixin_corn` values('73','a:3:{s:6:\"touser\";s:28:\"oAfaAw6rxfIWoqZlrN4QSaRzAvaU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";N;}}','1455640090','1455640090','2','66','5');");
E_D("replace into `ecs_weixin_corn` values('74','a:3:{s:6:\"touser\";s:28:\"oAfaAw6rxfIWoqZlrN4QSaRzAvaU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";N;}}','1455640119','1455640119','2','66','5');");
E_D("replace into `ecs_weixin_corn` values('75','a:3:{s:6:\"touser\";s:28:\"oAfaAw6rxfIWoqZlrN4QSaRzAvaU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";N;}}','1455640136','1455640136','2','66','5');");
E_D("replace into `ecs_weixin_corn` values('76','a:3:{s:6:\"touser\";s:28:\"oAfaAw6rxfIWoqZlrN4QSaRzAvaU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:33:\"会员卿丹成为您的下级了\";}}','1455640283','1455640283','2','66','5');");
E_D("replace into `ecs_weixin_corn` values('77','a:3:{s:6:\"touser\";s:28:\"oAfaAw6rxfIWoqZlrN4QSaRzAvaU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:27:\"会员成为您的下级了\";}}','1455640377','1455640377','2','66','5');");
E_D("replace into `ecs_weixin_corn` values('78','a:3:{s:6:\"touser\";s:28:\"oAfaAw6rxfIWoqZlrN4QSaRzAvaU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:39:\"会员wx_021720830成为您的下级了\";}}','1455640685','1455640685','2','66','5');");
E_D("replace into `ecs_weixin_corn` values('79','a:3:{s:6:\"touser\";s:28:\"oAfaAwztm28Zt7Pz-kHrX-MHtrB0\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1455716781','1455716781','2','188','1');");
E_D("replace into `ecs_weixin_corn` values('80','a:3:{s:6:\"touser\";s:28:\"oAfaAw7s7zcOViIMuOhDn_d0O6L8\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1455726262','1455726262','2','189','1');");
E_D("replace into `ecs_weixin_corn` values('81','a:3:{s:6:\"touser\";s:28:\"oAfaAwwOUqgbr3-U2vOc-TtsIiYA\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1455782756','1455782756','2','126','1');");
E_D("replace into `ecs_weixin_corn` values('82','a:3:{s:6:\"touser\";s:28:\"oAfaAwwOUqgbr3-U2vOc-TtsIiYA\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:39:\"会员wx_021827057成为您的下级了\";}}','1455783650','1455783650','2','126','5');");
E_D("replace into `ecs_weixin_corn` values('83','a:3:{s:6:\"touser\";s:28:\"oAfaAwwOUqgbr3-U2vOc-TtsIiYA\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:39:\"会员wx_021840789成为您的下级了\";}}','1455794716','1455794716','2','126','5');");
E_D("replace into `ecs_weixin_corn` values('84','a:3:{s:6:\"touser\";s:28:\"oAfaAww8wFAs0f5LETNUaEAfhZ0o\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1455854958','1455854958','2','197','1');");
E_D("replace into `ecs_weixin_corn` values('85','a:3:{s:6:\"touser\";s:28:\"oAfaAw1GGnXG9XSUMomrFwDyAgzw\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:39:\"会员wx_021927550成为您的下级了\";}}','1455873423','1455873423','2','199','5');");
E_D("replace into `ecs_weixin_corn` values('86','a:3:{s:6:\"touser\";s:28:\"oAfaAw2d3x4cCZXswLZQIoEdCYVU\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:39:\"会员wx_021994688成为您的下级了\";}}','1455873552','1455873552','2','200','5');");
E_D("replace into `ecs_weixin_corn` values('87','a:3:{s:6:\"touser\";s:28:\"oAfaAwwqhfXxpRJxx09SQJxox-uE\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1455952776','1455952776','2','209','1');");
E_D("replace into `ecs_weixin_corn` values('88','a:3:{s:6:\"touser\";s:28:\"oAfaAwyF4uXSZzGw0BQoFjM1Enck\";s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:30:\"恭喜你订单提交成功！\";}}','1456071507','1456071507','2','232','1');");

require("../../inc/footer.php");
?>