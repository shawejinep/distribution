<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_user_address`;");
E_C("CREATE TABLE `ecs_user_address` (
  `address_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `address_name` varchar(50) NOT NULL DEFAULT '',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `consignee` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `country` smallint(5) NOT NULL DEFAULT '0',
  `province` smallint(5) NOT NULL DEFAULT '0',
  `city` smallint(5) NOT NULL DEFAULT '0',
  `district` smallint(5) NOT NULL DEFAULT '0',
  `address` varchar(120) NOT NULL DEFAULT '',
  `zipcode` varchar(60) NOT NULL DEFAULT '',
  `tel` varchar(60) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  `sign_building` varchar(120) NOT NULL DEFAULT '',
  `best_time` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`address_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_user_address` values('1','','5','111','111@qq.com','1','2','52','500','111','11111','--','15032361111','','');");
E_D("replace into `ecs_user_address` values('2','','2','羊羊羊','22@qq.com','1','10','145','1194','河北大街西段666号','066000','--','13933528316','','');");
E_D("replace into `ecs_user_address` values('16','','1','anan','23456@qq.ukj','1','10','145','1194','森林逸城B区','','','18712345678','','');");
E_D("replace into `ecs_user_address` values('15','','2','喵喵','33@qq.com','1','2','52','500','河北大街','','--','13912345678','','');");
E_D("replace into `ecs_user_address` values('17','','12','Lxn','','1','10','145','1194','森林逸城','','','15133518792','','');");
E_D("replace into `ecs_user_address` values('18','','11','赵云龙','','1','10','145','1194','。。。。。。','','','13333344125','','');");
E_D("replace into `ecs_user_address` values('19','','10','ECSHOP开发中心','','1','10','145','1194','金海湾B座302','','','15903373514','','');");
E_D("replace into `ecs_user_address` values('20','','10','商之翼','','1','10','145','1194','秦皇岛商之翼网络科技有限公司','','','13755226428','','');");
E_D("replace into `ecs_user_address` values('21','','10','68ECSHOP','','1','10','145','1194','金海湾B座302','','','18855220000','','');");
E_D("replace into `ecs_user_address` values('22','','14','测试一下','','1','6','77','705','hhhhhhh','','-','13322222222','','');");
E_D("replace into `ecs_user_address` values('23','','10','Yyy','','1','4','56','551','Yyyyyy','','','15674553248','','');");
E_D("replace into `ecs_user_address` values('24','','21','High','xtony@126.com','1','6','77','705','金地工业区114幢501','','','18688955663','','');");
E_D("replace into `ecs_user_address` values('25','','22','博纳噢','fzpi123@26.com','1','6','76','696','吃啥','','','18922700300','','');");
E_D("replace into `ecs_user_address` values('26','','28','还是就睡觉吧','dnsjsbq@163.com','1','18','247','2094','把东西还上班不是','','','13130455321','','');");
E_D("replace into `ecs_user_address` values('27','','24','teg','605019058@qq.com','1','2','52','501','dhddh','','','13333333333','','');");
E_D("replace into `ecs_user_address` values('28','','29','123','123456@qq.com','1','2','52','504','123','','','12312312311','','');");
E_D("replace into `ecs_user_address` values('29','','30','特钢','34523@126.com','1','3','50','489','儿童为为认同为认同','242000','-','13333333333','','');");
E_D("replace into `ecs_user_address` values('30','','30','特工','','1','2','52','500','为认同为认同','','-','13333333333','','');");
E_D("replace into `ecs_user_address` values('31','','37','Xaduo','39187421@qq.com','1','25','321','2707','周浦万达','','','13120907009','','');");
E_D("replace into `ecs_user_address` values('32','','43','邬小君','1111@qq.com','1','6','78','712','1111','','','18638360405','','');");
E_D("replace into `ecs_user_address` values('33','','50','东哥','wx_122237069@163.com','1','2','52','501','东哥','','','18238816000','','');");
E_D("replace into `ecs_user_address` values('34','','47','理解理解','wx_122243525@163.com','1','5','64','619','啦啦吧','','','18638360405','','');");
E_D("replace into `ecs_user_address` values('35','','57','啦啦啦','wx_122311823@163.com','1','4','57','559','理解理解','','','18638360405','','');");
E_D("replace into `ecs_user_address` values('36','','67','东哥','wx_122354740@163.com','1','6','76','692','东哥','','','18238816000','','');");
E_D("replace into `ecs_user_address` values('37','','49','东哥','1039492672@qq.com','1','2','52','500','东哥','','','18238816000','','');");
E_D("replace into `ecs_user_address` values('38','','75','测试','wx_12245029@163.com','1','2','52','501','测试','','','15311111117','','');");
E_D("replace into `ecs_user_address` values('39','','74','小芳','wx_122469297@163.com','1','3','37','410','哼哼唧唧','','','15333844467','','');");
E_D("replace into `ecs_user_address` values('40','','100','測試','wx_122681743@163.com','1','3','36','398','，','','','13326322222','','');");
E_D("replace into `ecs_user_address` values('41','','102','得到','wx_122618997@163.com','1','2','52','502','啦咯啦咯啦咯了','','','13036533687','','');");
E_D("replace into `ecs_user_address` values('42','','105','啊哈哈','wx_122688340@163.com','1','3','36','398','很多时候是','','','12754545454','','');");
E_D("replace into `ecs_user_address` values('43','','110','挑剔','wx_122794838@163.com','1','4','55','539','改革','','','18676860999','','');");
E_D("replace into `ecs_user_address` values('44','','109','q q q1','wx_122754824@163.com','1','26','322','2722','中国','','','13111215425','','');");
E_D("replace into `ecs_user_address` values('45','','113','想吃','wx_122816129@163.com','1','2','52','500','尿尿','','','18918295283','','');");
E_D("replace into `ecs_user_address` values('46','','119','哈哈哈','wx_122875052@163.com','1','2','52','502','风风光光','','','15555555555','','');");
E_D("replace into `ecs_user_address` values('47','','120','张三','bdbdb123@126.com','1','3','36','398','把烦恼的你','','','15215421542','','');");
E_D("replace into `ecs_user_address` values('48','','120','张三','bdbdb123@126.com','1','3','36','398','把烦恼的你','','','15215421542','','');");
E_D("replace into `ecs_user_address` values('49','','124','刘锋','','1','17','235','1981','赣江源大道','','-','13870770708','','');");
E_D("replace into `ecs_user_address` values('50','','126','廖文博','wx_122892190@163.com','1','3','36','399','测试','','','18566003377','','');");
E_D("replace into `ecs_user_address` values('51','','129','刘捐','wx_122920307@163.com','1','2','52','510','北京市砖厂北里','','','18001389870','','');");
E_D("replace into `ecs_user_address` values('52','','128','南山','wx_122965947@163.com','1','2','52','500','东城街道办事处','','','15985623365','','');");
E_D("replace into `ecs_user_address` values('53','','90','刘锋','wx_122517229@163.com','1','8','114','988','而谈','','','13870770708','','');");
E_D("replace into `ecs_user_address` values('54','','130','袁凯轩','1321@qq.com','1','2','52','501','ass放大发发司法','338000','-','13979072522','','');");
E_D("replace into `ecs_user_address` values('55','','140','经济','wx_123060402@163.com','1','12','170','1450','家里面','','','13888965423','','');");
E_D("replace into `ecs_user_address` values('56','','140','经济','wx_123060402@163.com','1','12','170','1450','家里面','','','13888965423','','');");
E_D("replace into `ecs_user_address` values('57','','144','陈杰','57975@126.com','1','25','321','2706','罗秀路955','','','13321999113','','');");
E_D("replace into `ecs_user_address` values('58','','146','123123','123123@qq.com','1','3','38','416','123123','','-','13213874545','','');");
E_D("replace into `ecs_user_address` values('59','','147','好呢','wx_123181821@163.com','1','6','76','692','害你','','','13213254343','','');");
E_D("replace into `ecs_user_address` values('60','','148','chen','wx_123144216@163.com','1','25','321','2706','罗秀路955','','','13321999113','','');");
E_D("replace into `ecs_user_address` values('61','','66','11111','wx_122364019@163.com','1','5','65','629','zsdfffgg','','','18638360405','','');");
E_D("replace into `ecs_user_address` values('62','','166','123','wx_010356053@163.com','1','7','101','902','123','','','18628812782','','');");
E_D("replace into `ecs_user_address` values('63','','167','我们的','wx_010413475@163.com','1','4','57','560','我们都市','','','15397421235','','');");
E_D("replace into `ecs_user_address` values('64','','117','test','wx_122885815@163.com','1','6','77','707','详细地址','','','14715025036','','');");
E_D("replace into `ecs_user_address` values('65','','170','甜小美','541967330@qq.com','1','11','150','1272','开元开元','4152631','-','18937176718','','');");
E_D("replace into `ecs_user_address` values('66','','188','旅三','wx_02174903@163.com','1','6','79','718','123号','','','15888888888','','');");
E_D("replace into `ecs_user_address` values('67','','189','孟召臣','wx_021766073@163.com','1','2','52','502','开明咯哦哦','','','13393369999','','');");
E_D("replace into `ecs_user_address` values('68','','197','刘','wx_021992027@163.com','1','17','236','2005','1','','','18657108965','','');");
E_D("replace into `ecs_user_address` values('69','','209','快快快','wx_022063197@163.com','1','5','64','622','考虑兔兔','','','18782247580','','');");
E_D("replace into `ecs_user_address` values('71','','224','aaa','wx_022155368@163.com','1','6','76','700','高规格','','','18819490527','','');");
E_D("replace into `ecs_user_address` values('72','','230','22212122','wx_022198296@163.com','1','3','38','420','235546545','','','13489362911','','');");
E_D("replace into `ecs_user_address` values('73','','232','信步','wx_022181921@163.com','1','24','313','2620','经二路','','','13212345678','','');");

require("../../inc/footer.php");
?>