<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_jflog`;");
E_C("CREATE TABLE `ecs_weixin_jflog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fake_id` varchar(32) NOT NULL,
  `jf_type` int(11) NOT NULL COMMENT '1 一次性赠送 2按日计算',
  `key_id` int(11) NOT NULL COMMENT '命令ID',
  `createtime` int(11) NOT NULL,
  `createymd` date NOT NULL,
  `num` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fake_id` (`fake_id`),
  KEY `createymd` (`createymd`),
  KEY `key_id` (`key_id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_jflog` values('1','oAfaAw6rxfIWoqZlrN4QSaRzAvaU','0','0','1450888870','2015-12-24','1');");
E_D("replace into `ecs_weixin_jflog` values('2','oAfaAwwSATwy7uCFABoTMzS_ggzQ','0','0','1450927302','2015-12-24','1');");
E_D("replace into `ecs_weixin_jflog` values('3','oAfaAw5lO0UcIlg97h5f8xZsdzgA','0','0','1450952878','2015-12-24','1');");
E_D("replace into `ecs_weixin_jflog` values('4','oAfaAwxyy28mQvhsHyxryTiMjyzI','0','0','1450975212','2015-12-25','1');");
E_D("replace into `ecs_weixin_jflog` values('5','oAfaAw0ql951-2XMNrURsLwwzW1A','0','0','1450980116','2015-12-25','1');");
E_D("replace into `ecs_weixin_jflog` values('6','oAfaAw8XwcqOZtl_-clDEsA7GG7s','0','0','1451010073','2015-12-25','1');");
E_D("replace into `ecs_weixin_jflog` values('7','oAfaAw111RaygiYoBZosGUYTc-as','0','0','1451025236','2015-12-25','1');");
E_D("replace into `ecs_weixin_jflog` values('8','oAfaAw6rxfIWoqZlrN4QSaRzAvaU','0','0','1451067956','2015-12-26','1');");
E_D("replace into `ecs_weixin_jflog` values('9','oAfaAw7UH38e_mJSkC50q9sb0jAQ','0','0','1451074792','2015-12-26','1');");
E_D("replace into `ecs_weixin_jflog` values('10','oAfaAwwhn2Vp6xfvBArtzXAsxROc','0','0','1451185540','2015-12-27','1');");
E_D("replace into `ecs_weixin_jflog` values('11','oAfaAw41VhD2crhBDmRo4RwcG7Xw','0','0','1451187301','2015-12-27','1');");
E_D("replace into `ecs_weixin_jflog` values('12','oAfaAw0ql951-2XMNrURsLwwzW1A','0','0','1451212793','2015-12-27','1');");
E_D("replace into `ecs_weixin_jflog` values('13','oAfaAw3EtN9O0xvbB3DpLIYQzK3k','0','0','1451296876','2015-12-28','1');");
E_D("replace into `ecs_weixin_jflog` values('14','oAfaAw7r88xeoEPm5VLBHySmRW5M','0','0','1451306113','2015-12-28','1');");
E_D("replace into `ecs_weixin_jflog` values('15','oAfaAwwIEstTFch1fJdfEJMn0zBc','0','0','1451317150','2015-12-28','1');");
E_D("replace into `ecs_weixin_jflog` values('16','oAfaAw41VhD2crhBDmRo4RwcG7Xw','0','0','1451324101','2015-12-29','1');");
E_D("replace into `ecs_weixin_jflog` values('17','oAfaAwwOUqgbr3-U2vOc-TtsIiYA','0','0','1451358918','2015-12-29','1');");
E_D("replace into `ecs_weixin_jflog` values('18','oAfaAw95HxlNqoXCUzt77IrciqFI','0','0','1451367503','2015-12-29','1');");
E_D("replace into `ecs_weixin_jflog` values('19','oAfaAw41VhD2crhBDmRo4RwcG7Xw','0','0','1451465275','2015-12-30','2');");
E_D("replace into `ecs_weixin_jflog` values('20','oAfaAw41VhD2crhBDmRo4RwcG7Xw','0','0','1451666641','2016-01-02','1');");
E_D("replace into `ecs_weixin_jflog` values('21','oAfaAwx44h6qxxWUBn28fPB5_6Qw','0','0','1451670218','2016-01-02','1');");
E_D("replace into `ecs_weixin_jflog` values('22','oAfaAw9_YRtonSuTcMXXPufO0d2E','0','0','1451737207','2016-01-02','1');");
E_D("replace into `ecs_weixin_jflog` values('23','oAfaAw0ql951-2XMNrURsLwwzW1A','0','0','1451812687','2016-01-03','1');");
E_D("replace into `ecs_weixin_jflog` values('24','oAfaAw8XwcqOZtl_-clDEsA7GG7s','0','0','1451870390','2016-01-04','1');");
E_D("replace into `ecs_weixin_jflog` values('25','oAfaAwwPoAWUptjBfy5tboC7XSuQ','0','0','1451901055','2016-01-04','1');");
E_D("replace into `ecs_weixin_jflog` values('26','oAfaAw6rxfIWoqZlrN4QSaRzAvaU','0','0','1451976311','2016-01-05','1');");
E_D("replace into `ecs_weixin_jflog` values('27','oAfaAww-assnJIFP7xvK7K72EUWg','0','0','1455694716','2016-02-17','1');");
E_D("replace into `ecs_weixin_jflog` values('28','oAfaAw7s7zcOViIMuOhDn_d0O6L8','0','0','1455725135','2016-02-18','1');");
E_D("replace into `ecs_weixin_jflog` values('29','oAfaAw41VhD2crhBDmRo4RwcG7Xw','0','0','1455735777','2016-02-18','1');");
E_D("replace into `ecs_weixin_jflog` values('30','oAfaAw65iWQJvNwBM_uGMP6s0Cok','0','0','1455951736','2016-02-20','1');");
E_D("replace into `ecs_weixin_jflog` values('31','oAfaAw1GGnXG9XSUMomrFwDyAgzw','0','0','1455991373','2016-02-21','1');");
E_D("replace into `ecs_weixin_jflog` values('32','oAfaAwxYKNDA-0LvuNAUydJEUDdk','0','0','1456023834','2016-02-21','1');");
E_D("replace into `ecs_weixin_jflog` values('33','oAfaAw8l8tgRg874mPwyKrLMydUg','0','0','1456043990','2016-02-21','1');");
E_D("replace into `ecs_weixin_jflog` values('34','oAfaAw5AORsTGz9St-EclhMkU0Lo','0','0','1456047078','2016-02-21','1');");
E_D("replace into `ecs_weixin_jflog` values('35','oAfaAw3wh58amDBvOjUA6iLfO2Eo','0','0','1456059272','2016-02-21','1');");
E_D("replace into `ecs_weixin_jflog` values('36','oAfaAw65iWQJvNwBM_uGMP6s0Cok','0','0','1456069975','2016-02-21','2');");

require("../../inc/footer.php");
?>