<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_supplier_admin_user`;");
E_C("CREATE TABLE `ecs_supplier_admin_user` (
  `user_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '存放users表中的user_id',
  `user_name` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `ec_salt` varchar(10) DEFAULT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `last_login` int(11) NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL DEFAULT '',
  `action_list` text NOT NULL,
  `nav_list` text NOT NULL,
  `lang_type` varchar(50) NOT NULL DEFAULT '',
  `agency_id` smallint(5) unsigned NOT NULL,
  `supplier_id` int(10) unsigned DEFAULT '0',
  `todolist` longtext,
  `role_id` smallint(5) DEFAULT NULL,
  `checked` tinyint(2) NOT NULL DEFAULT '0' COMMENT '-1:审核未通过,0:未审核,1审核通过',
  PRIMARY KEY (`user_id`),
  KEY `user_name` (`user_name`),
  KEY `agency_id` (`agency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_supplier_admin_user` values('1','1','anan','anan@68ecshop.com','7d6e7750d27c1e3e2739d4ff82af0038','3121','1437497970','1456029870','1.82.170.169','all','','','0','1',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('2','2','68ecshopyy','285188787@qq.com','a8f7dfa3deb1c6e36b21c4fd5194db7c','4460','1437500040','1445762810','1.193.89.239','all','','','0','2',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('4','5','leilei','2691111111@qq.com','96e79218965eb72c92a549dd5a330112','','1437502269','1451898232','113.93.18.98','all','','','0','5',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('6','6','yiren','3490134@qq.com','2d14f0a7ff531d44baa35a0f98ea9f39','','1437503705','1443383704','124.237.90.162','all','','','0','6',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('7','7','liuyu','33342@qq.com','9925a305924fddf8a7fea60b838d844b','6109','1437520761','1437699597','192.168.1.162','all','','','0','7',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('8','8','liza','222222@qq.com','2d14f0a7ff531d44baa35a0f98ea9f39','','1437525999','1437702335','192.168.1.162','all','','','0','8',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('10','21','test8888','xtony@126.com','212a379ce4ac52f643a0955cfff7f4ef','1546','1444782926','1445749530','183.38.223.144','all','','','0','11',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('11','30','u133UUNT1706','','e842f30119f5e6649c10512d04b6a732','8306','1445835174','1445847962','101.200.75.223','all','','','0','15',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('12','49','u208JAU4782','1039492672@qq.com','c879338c69ecbccc7a32f6deb29f6d66','1342','1450945886','1451970417','211.103.255.7','all','','','0','16',NULL,NULL,'1');");
E_D("replace into `ecs_supplier_admin_user` values('13','0','老五','12@12.com','0fbf5472e4613bd5004545041ac434cf',NULL,'1455661230','0','','','','','0','1',NULL,'0','1');");

require("../../inc/footer.php");
?>