<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_cart`;");
E_C("CREATE TABLE `ecs_cart` (
  `rec_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `session_id` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `goods_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_sn` varchar(60) NOT NULL DEFAULT '',
  `product_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_name` varchar(120) NOT NULL DEFAULT '',
  `market_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `goods_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `split_money` decimal(10,2) NOT NULL,
  `goods_number` smallint(5) unsigned NOT NULL DEFAULT '0',
  `goods_attr` text NOT NULL,
  `is_real` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `extension_code` varchar(30) NOT NULL DEFAULT '',
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rec_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_gift` smallint(5) unsigned NOT NULL DEFAULT '0',
  `is_shipping` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `can_handsel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `goods_attr_id` varchar(255) NOT NULL DEFAULT '',
  `add_time` int(10) unsigned NOT NULL,
  `package_attr_id` varchar(100) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `promote_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`rec_id`),
  KEY `session_id` (`session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=290 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_cart` values('288','232','a0f47ff48107c1c3d75847ff7b1be039','119','ECS000119','0','艾生活 真皮床双人床 独特围边 精细做工 卧室家具','3912.00','3260.00','0.00','1','','1','','0','0','0','0','0','','1456042775','','0.00','0.00');");
E_D("replace into `ecs_cart` values('289','0','99cbdccf192a51a1086eb6b396815ef7','28','ECS000028','0','进口费列罗巧克力礼盒DIY心形27粒【顺丰包邮】【代写贺卡】七夕礼物生日创意礼品','144.00','120.00','0.00','1','','1','','0','0','0','0','0','','1456192012','','0.00','0.00');");
E_D("replace into `ecs_cart` values('282','230','c5a55542d284ac7b844d6f6c60417690','137','ECS000137','0','LOVO 罗莱家纺出品全棉斜纹床品套件四件套 兔斯基','478.79','399.00','0.00','1','','1','','0','0','0','0','0','','1456038900','','0.00','0.00');");

require("../../inc/footer.php");
?>