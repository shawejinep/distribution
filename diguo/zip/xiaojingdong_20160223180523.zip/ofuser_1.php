<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ofuser`;");
E_C("CREATE TABLE `ofuser` (
  `username` varchar(64) NOT NULL,
  `plainPassword` varchar(32) DEFAULT NULL,
  `encryptedPassword` varchar(255) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `creationDate` char(15) NOT NULL,
  `modificationDate` char(15) NOT NULL,
  PRIMARY KEY (`username`),
  KEY `ofUser_cDate_idx` (`creationDate`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `ofuser` values('admin',NULL,'ff01ee16f66de98455a730ef79676ae20b3968db511a32c914a9b8a924a592da','Administrator','admin@example.com','001443975536747','0');");
E_D("replace into `ofuser` values('test',NULL,'a753ed4a8d86d97b20bd301679377b9700f02e1f6b66908b',NULL,NULL,'001443976424903','001443976424903');");

require("../../inc/footer.php");
?>