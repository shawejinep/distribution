<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_delivery_goods`;");
E_C("CREATE TABLE `ecs_delivery_goods` (
  `rec_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `product_id` mediumint(8) unsigned DEFAULT '0',
  `product_sn` varchar(60) DEFAULT NULL,
  `goods_name` varchar(120) DEFAULT NULL,
  `brand_name` varchar(60) DEFAULT NULL,
  `goods_sn` varchar(60) DEFAULT NULL,
  `is_real` tinyint(1) unsigned DEFAULT '0',
  `extension_code` varchar(30) DEFAULT NULL,
  `parent_id` mediumint(8) unsigned DEFAULT '0',
  `send_number` smallint(5) unsigned DEFAULT '0',
  `goods_attr` text,
  PRIMARY KEY (`rec_id`),
  KEY `delivery_id` (`delivery_id`,`goods_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_delivery_goods` values('1','1','231','0','','可爱卡通餐盘水果盘点心盘 盘子儿童托盘餐具6件套','格兰仕','ECS000231','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('2','2','100','26','ECS000100g_p26','苹果（Apple）iPhone 6 (A1586) 16GB 金色 移动联通电信4G手机','苹果','ECS000100','1',NULL,'0','2','颜色:银色[100] \n');");
E_D("replace into `ecs_delivery_goods` values('3','3','29','0','','意大利费列罗巧克力食品进口零食礼盒576粒整箱装结婚喜糖','口水娃','ECS000029','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('4','4','235','0','','sfsdsdfsdf','','sdfsdfsd','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('5','5','26','0','','韩国进口X-5花生夹心巧克力棒盒装（24根）864g','锐澳','ECS000026','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('6','6','68','0','','新西兰 原装进口 纯牛奶 纽麦福（ Meadow fresh ）全脂1L*12盒/箱','三元','ECS000068','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('7','7','121','0','','Midea/美的 KFR-26GW/WJBA3@ 大1匹智能云除甲醛除湿冷暖变频空调','','ECS000121','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('8','8','223','0','','乐和居 双人床 床 榻榻米床 头层真皮','爱华仕','ECS000223','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('9','9','223','0','','乐和居 双人床 床 榻榻米床 头层真皮','爱华仕','ECS000223','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('10','10','117','0','',' CKTF-32GS上下独立控温 多功能电烤箱家用烘焙烤箱 正品特价','格力','ECS000117','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('11','11','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('12','12','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('13','13','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('14','14','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('15','15','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('16','16','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('17','17','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('18','18','191','0','','雪奈儿 金属边框手机壳套保护壳新款 适用于苹果iPhone6/Plus 4.7英寸 利剑i6土豪金5.5','中兴','ECS000191','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('19','19','100','27','ECS000100g_p27','苹果（Apple）iPhone 6 (A1586) 16GB 金色 移动联通电信4G手机','苹果','ECS000100','1',NULL,'0','1','颜色:白色 \n');");
E_D("replace into `ecs_delivery_goods` values('20','20','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('21','21','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('22','22','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('23','23','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('24','24','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('25','25','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('26','26','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('27','27','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('28','28','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('29','29','200','0','','爱度AY800蓝牙音箱手机电脑迷你音响无线便携插卡低音炮 带蓝牙自拍 土豪金','伊莱克斯','ECS000200','1',NULL,'0','4','');");
E_D("replace into `ecs_delivery_goods` values('30','30','24','0','','悦胜 挪威超新鲜三文鱼 三文鱼中段刺身进口海鲜 广东2份包邮 三文鱼新鲜 500g','','ECS000024','1',NULL,'0','2','');");
E_D("replace into `ecs_delivery_goods` values('31','31','3','0','','美国西北车厘子 1斤装 进口水果新鲜樱桃水果','','ECS000003','1',NULL,'0','3','');");
E_D("replace into `ecs_delivery_goods` values('32','32','4','0','','加拿大樱桃 2斤装 车厘子 樱桃 进口水果 新鲜水果','','ECS000004','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('33','33','23','0','','进口 新鲜水果 车厘子1000g','','ECS000023','1',NULL,'0','2','');");
E_D("replace into `ecs_delivery_goods` values('34','33','23','0','','进口 新鲜水果 车厘子1000g','','ECS000023','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('35','34','4','0','','加拿大樱桃 2斤装 车厘子 樱桃 进口水果 新鲜水果','','ECS000004','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('36','35','4','0','','加拿大樱桃 2斤装 车厘子 樱桃 进口水果 新鲜水果','','ECS000004','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('37','36','23','0','','进口 新鲜水果 车厘子1000g','','ECS000023','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('38','37','205','0','','索爱（soaiy）S-20 便携式蓝牙数码插卡智能音箱 青春版 珍珠白','贝古贝古','ECS000205','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('39','38','24','0','','悦胜 挪威超新鲜三文鱼 三文鱼中段刺身进口海鲜 广东2份包邮 三文鱼新鲜 500g','','ECS000024','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('40','39','16','0','','畅享礼盒 奇异果火龙果佳节送礼进口新鲜水果','','ECS000016','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('41','40','16','0','','畅享礼盒 奇异果火龙果佳节送礼进口新鲜水果','','ECS000016','1',NULL,'0','1','');");
E_D("replace into `ecs_delivery_goods` values('42','41','34','1','ECS000034g_p1','夏装甜美爱心提花蕾丝连衣裙女 宽松欧根纱背心裙','曼妮芬（ManniForm）','ECS000034','1',NULL,'0','1','颜色:米色 \n尺码:M \n');");

require("../../inc/footer.php");
?>