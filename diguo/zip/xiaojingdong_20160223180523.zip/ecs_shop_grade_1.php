<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_shop_grade`;");
E_C("CREATE TABLE `ecs_shop_grade` (
  `grade_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(60) NOT NULL,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_rank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `server` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `order_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_sn` varchar(20) NOT NULL,
  `is_comment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`grade_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_shop_grade` values('1','21','test8888','1445476244','0','5','5','5','40','2015102158764','1');");
E_D("replace into `ecs_shop_grade` values('2','105','wx_122688340','1451071295','0','5','5','5','76','2015122637454','1');");
E_D("replace into `ecs_shop_grade` values('3','120','wx_122893410','1451268858','0','5','5','5','90','2015122881446','1');");

require("../../inc/footer.php");
?>