<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_user_deposit`;");
E_C("CREATE TABLE `ecs_user_deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `real_name` varchar(255) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `bank_account` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_user_deposit` values('1','一','一','111111111','13333333333','','26');");
E_D("replace into `ecs_user_deposit` values('2','东哥','建行','622','18238816000','备注','49');");

require("../../inc/footer.php");
?>