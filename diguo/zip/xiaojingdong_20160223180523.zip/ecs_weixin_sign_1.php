<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_sign`;");
E_C("CREATE TABLE `ecs_weixin_sign` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `wxid` int(11) NOT NULL,
  `signtime` int(11) NOT NULL,
  `signymd` date NOT NULL,
  PRIMARY KEY (`sid`),
  UNIQUE KEY `wxid` (`wxid`,`signymd`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_sign` values('1','16','1450888870','2015-12-24');");
E_D("replace into `ecs_weixin_sign` values('2','31','1450927302','2015-12-24');");
E_D("replace into `ecs_weixin_sign` values('3','43','1450952878','2015-12-24');");
E_D("replace into `ecs_weixin_sign` values('4','51','1450975212','2015-12-25');");
E_D("replace into `ecs_weixin_sign` values('5','37','1450980116','2015-12-25');");
E_D("replace into `ecs_weixin_sign` values('6','44','1451010073','2015-12-25');");
E_D("replace into `ecs_weixin_sign` values('7','61','1451025236','2015-12-25');");
E_D("replace into `ecs_weixin_sign` values('8','16','1451067956','2015-12-26');");
E_D("replace into `ecs_weixin_sign` values('9','62','1451074792','2015-12-26');");
E_D("replace into `ecs_weixin_sign` values('10','78','1451185540','2015-12-27');");
E_D("replace into `ecs_weixin_sign` values('11','79','1451187301','2015-12-27');");
E_D("replace into `ecs_weixin_sign` values('12','37','1451212793','2015-12-27');");
E_D("replace into `ecs_weixin_sign` values('13','91','1451296876','2015-12-28');");
E_D("replace into `ecs_weixin_sign` values('14','38','1451306113','2015-12-28');");
E_D("replace into `ecs_weixin_sign` values('15','96','1451317150','2015-12-28');");
E_D("replace into `ecs_weixin_sign` values('16','79','1451324101','2015-12-29');");
E_D("replace into `ecs_weixin_sign` values('17','97','1451358918','2015-12-29');");
E_D("replace into `ecs_weixin_sign` values('18','104','1451367503','2015-12-29');");
E_D("replace into `ecs_weixin_sign` values('19','79','1451465275','2015-12-30');");
E_D("replace into `ecs_weixin_sign` values('20','79','1451666641','2016-01-02');");
E_D("replace into `ecs_weixin_sign` values('21','135','1451670218','2016-01-02');");
E_D("replace into `ecs_weixin_sign` values('22','142','1451737207','2016-01-02');");
E_D("replace into `ecs_weixin_sign` values('23','37','1451812687','2016-01-03');");
E_D("replace into `ecs_weixin_sign` values('24','44','1451870390','2016-01-04');");
E_D("replace into `ecs_weixin_sign` values('25','126','1451901055','2016-01-04');");
E_D("replace into `ecs_weixin_sign` values('26','16','1451976311','2016-01-05');");
E_D("replace into `ecs_weixin_sign` values('27','169','1455694716','2016-02-17');");
E_D("replace into `ecs_weixin_sign` values('28','172','1455725135','2016-02-18');");
E_D("replace into `ecs_weixin_sign` values('29','79','1455735777','2016-02-18');");
E_D("replace into `ecs_weixin_sign` values('30','166','1455794674','2016-02-18');");
E_D("replace into `ecs_weixin_sign` values('31','188','1455951736','2016-02-20');");
E_D("replace into `ecs_weixin_sign` values('32','180','1455991373','2016-02-21');");
E_D("replace into `ecs_weixin_sign` values('33','194','1456023834','2016-02-21');");
E_D("replace into `ecs_weixin_sign` values('34','203','1456043990','2016-02-21');");
E_D("replace into `ecs_weixin_sign` values('35','205','1456047078','2016-02-21');");
E_D("replace into `ecs_weixin_sign` values('36','202','1456059272','2016-02-21');");
E_D("replace into `ecs_weixin_sign` values('37','188','1456069975','2016-02-21');");

require("../../inc/footer.php");
?>