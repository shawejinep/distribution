<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `ofid`;");
E_C("CREATE TABLE `ofid` (
  `idType` int(11) NOT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`idType`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `ofid` values('18','1');");
E_D("replace into `ofid` values('19','1');");
E_D("replace into `ofid` values('23','1');");
E_D("replace into `ofid` values('26','2');");
E_D("replace into `ofid` values('25','2');");

require("../../inc/footer.php");
?>