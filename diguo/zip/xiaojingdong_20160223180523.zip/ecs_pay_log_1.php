<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_pay_log`;");
E_C("CREATE TABLE `ecs_pay_log` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_amount` decimal(10,2) unsigned NOT NULL,
  `order_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_paid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=135 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_pay_log` values('1','1','200.00','1','0');");
E_D("replace into `ecs_pay_log` values('2','142','334.90','0','0');");
E_D("replace into `ecs_pay_log` values('3','143','494.00','0','0');");
E_D("replace into `ecs_pay_log` values('4','144','74.00','0','0');");
E_D("replace into `ecs_pay_log` values('5','141','902.90','0','0');");
E_D("replace into `ecs_pay_log` values('6','1','178.50','0','0');");
E_D("replace into `ecs_pay_log` values('7','2','117.50','0','0');");
E_D("replace into `ecs_pay_log` values('8','3','104.00','0','0');");
E_D("replace into `ecs_pay_log` values('9','4','104.00','0','0');");
E_D("replace into `ecs_pay_log` values('10','5','0.00','0','0');");
E_D("replace into `ecs_pay_log` values('11','6','104.00','0','0');");
E_D("replace into `ecs_pay_log` values('12','7','1844.50','0','0');");
E_D("replace into `ecs_pay_log` values('13','8','154.00','0','0');");
E_D("replace into `ecs_pay_log` values('14','9','154.00','0','0');");
E_D("replace into `ecs_pay_log` values('15','10','154.00','0','0');");
E_D("replace into `ecs_pay_log` values('16','11','8983.40','0','0');");
E_D("replace into `ecs_pay_log` values('17','3','5000.00','1','0');");
E_D("replace into `ecs_pay_log` values('18','12','74.00','0','0');");
E_D("replace into `ecs_pay_log` values('19','13','0.00','0','0');");
E_D("replace into `ecs_pay_log` values('20','14','17.00','0','0');");
E_D("replace into `ecs_pay_log` values('21','15','0.00','0','0');");
E_D("replace into `ecs_pay_log` values('22','16','325.00','0','0');");
E_D("replace into `ecs_pay_log` values('23','17','4159.80','0','0');");
E_D("replace into `ecs_pay_log` values('24','5','10.00','1','0');");
E_D("replace into `ecs_pay_log` values('25','6','10.00','1','0');");
E_D("replace into `ecs_pay_log` values('26','7','12.00','1','0');");
E_D("replace into `ecs_pay_log` values('27','18','143.00','0','0');");
E_D("replace into `ecs_pay_log` values('28','19','143.00','0','0');");
E_D("replace into `ecs_pay_log` values('29','20','271.00','0','0');");
E_D("replace into `ecs_pay_log` values('30','21','134.00','0','0');");
E_D("replace into `ecs_pay_log` values('31','22','134.00','0','0');");
E_D("replace into `ecs_pay_log` values('32','23','143.00','0','0');");
E_D("replace into `ecs_pay_log` values('33','24','143.00','0','0');");
E_D("replace into `ecs_pay_log` values('34','25','124.00','0','0');");
E_D("replace into `ecs_pay_log` values('35','26','143.00','0','0');");
E_D("replace into `ecs_pay_log` values('36','27','570.00','0','0');");
E_D("replace into `ecs_pay_log` values('37','28','84.00','0','0');");
E_D("replace into `ecs_pay_log` values('38','29','203.00','0','0');");
E_D("replace into `ecs_pay_log` values('39','30','570.00','0','0');");
E_D("replace into `ecs_pay_log` values('40','31','233.00','0','0');");
E_D("replace into `ecs_pay_log` values('41','32','134.00','0','0');");
E_D("replace into `ecs_pay_log` values('42','33','24.90','0','0');");
E_D("replace into `ecs_pay_log` values('43','34','24.90','0','0');");
E_D("replace into `ecs_pay_log` values('44','35','94.00','0','0');");
E_D("replace into `ecs_pay_log` values('45','36','44.00','0','0');");
E_D("replace into `ecs_pay_log` values('46','37','84.00','0','0');");
E_D("replace into `ecs_pay_log` values('47','38','3852.00','0','0');");
E_D("replace into `ecs_pay_log` values('48','39','470.00','0','0');");
E_D("replace into `ecs_pay_log` values('49','40','570.00','0','0');");
E_D("replace into `ecs_pay_log` values('50','41','570.00','0','0');");
E_D("replace into `ecs_pay_log` values('51','42','94.00','0','0');");
E_D("replace into `ecs_pay_log` values('52','43','66.00','0','0');");
E_D("replace into `ecs_pay_log` values('53','44','135.00','0','0');");
E_D("replace into `ecs_pay_log` values('54','45','94.00','0','0');");
E_D("replace into `ecs_pay_log` values('55','46','50.00','0','0');");
E_D("replace into `ecs_pay_log` values('56','47','44.00','0','0');");
E_D("replace into `ecs_pay_log` values('57','48','214.00','0','0');");
E_D("replace into `ecs_pay_log` values('58','49','213.00','0','0');");
E_D("replace into `ecs_pay_log` values('59','50','131.00','0','0');");
E_D("replace into `ecs_pay_log` values('60','51','570.00','0','0');");
E_D("replace into `ecs_pay_log` values('61','52','50.00','0','0');");
E_D("replace into `ecs_pay_log` values('62','53','50.00','0','0');");
E_D("replace into `ecs_pay_log` values('63','54','143.00','0','0');");
E_D("replace into `ecs_pay_log` values('64','55','50.00','0','0');");
E_D("replace into `ecs_pay_log` values('65','56','193.00','0','0');");
E_D("replace into `ecs_pay_log` values('66','57','95.00','0','0');");
E_D("replace into `ecs_pay_log` values('67','58','2214.00','0','0');");
E_D("replace into `ecs_pay_log` values('68','59','94.00','0','0');");
E_D("replace into `ecs_pay_log` values('69','60','26.00','0','0');");
E_D("replace into `ecs_pay_log` values('70','61','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('71','62','2260.00','0','0');");
E_D("replace into `ecs_pay_log` values('72','63','3014.00','0','0');");
E_D("replace into `ecs_pay_log` values('73','64','243.60','0','0');");
E_D("replace into `ecs_pay_log` values('74','65','85.20','0','0');");
E_D("replace into `ecs_pay_log` values('75','66','4414.20','0','0');");
E_D("replace into `ecs_pay_log` values('76','67','348.20','0','0');");
E_D("replace into `ecs_pay_log` values('77','68','132.60','0','0');");
E_D("replace into `ecs_pay_log` values('78','69','73.95','0','0');");
E_D("replace into `ecs_pay_log` values('79','70','108.80','0','0');");
E_D("replace into `ecs_pay_log` values('80','71','404.90','0','0');");
E_D("replace into `ecs_pay_log` values('81','72','108.80','0','0');");
E_D("replace into `ecs_pay_log` values('82','73','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('83','74','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('84','75','26.00','0','0');");
E_D("replace into `ecs_pay_log` values('85','76','234.00','0','0');");
E_D("replace into `ecs_pay_log` values('86','77','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('87','78','37.00','0','0');");
E_D("replace into `ecs_pay_log` values('88','79','37.00','0','0');");
E_D("replace into `ecs_pay_log` values('89','80','104.00','0','0');");
E_D("replace into `ecs_pay_log` values('90','81','214.00','0','0');");
E_D("replace into `ecs_pay_log` values('91','82','214.00','0','0');");
E_D("replace into `ecs_pay_log` values('92','83','4714.00','0','0');");
E_D("replace into `ecs_pay_log` values('93','84','214.00','0','0');");
E_D("replace into `ecs_pay_log` values('94','85','244.00','0','0');");
E_D("replace into `ecs_pay_log` values('95','86','2214.00','0','0');");
E_D("replace into `ecs_pay_log` values('96','87','414.00','0','0');");
E_D("replace into `ecs_pay_log` values('97','88','37.00','0','0');");
E_D("replace into `ecs_pay_log` values('98','89','204.00','0','0');");
E_D("replace into `ecs_pay_log` values('99','90','78.00','0','0');");
E_D("replace into `ecs_pay_log` values('100','91','26.00','0','0');");
E_D("replace into `ecs_pay_log` values('101','92','27.00','0','0');");
E_D("replace into `ecs_pay_log` values('102','93','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('103','94','253.00','0','0');");
E_D("replace into `ecs_pay_log` values('104','95','214.00','0','0');");
E_D("replace into `ecs_pay_log` values('105','96','78.00','0','0');");
E_D("replace into `ecs_pay_log` values('106','97','78.00','0','0');");
E_D("replace into `ecs_pay_log` values('107','98','58.00','0','0');");
E_D("replace into `ecs_pay_log` values('108','99','19.00','0','0');");
E_D("replace into `ecs_pay_log` values('109','100','168.00','0','0');");
E_D("replace into `ecs_pay_log` values('110','101','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('111','102','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('112','103','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('113','104','4903.00','0','0');");
E_D("replace into `ecs_pay_log` values('114','105','3852.00','0','0');");
E_D("replace into `ecs_pay_log` values('115','106','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('116','107','114.00','0','0');");
E_D("replace into `ecs_pay_log` values('117','108','173.00','0','0');");
E_D("replace into `ecs_pay_log` values('118','109','304.00','0','0');");
E_D("replace into `ecs_pay_log` values('119','110','999.00','0','0');");
E_D("replace into `ecs_pay_log` values('120','111','94.00','0','0');");
E_D("replace into `ecs_pay_log` values('121','112','304.00','0','0');");
E_D("replace into `ecs_pay_log` values('122','113','183.00','0','0');");
E_D("replace into `ecs_pay_log` values('123','114','0.00','0','0');");
E_D("replace into `ecs_pay_log` values('124','8','100.00','1','0');");
E_D("replace into `ecs_pay_log` values('125','115','203.00','0','0');");
E_D("replace into `ecs_pay_log` values('126','116','284.00','0','0');");
E_D("replace into `ecs_pay_log` values('127','117','5494.20','0','0');");
E_D("replace into `ecs_pay_log` values('128','118','5494.20','0','0');");
E_D("replace into `ecs_pay_log` values('129','119','94.00','0','0');");
E_D("replace into `ecs_pay_log` values('130','120','304.00','0','0');");
E_D("replace into `ecs_pay_log` values('131','122','144.00','0','0');");
E_D("replace into `ecs_pay_log` values('132','123','304.00','0','0');");
E_D("replace into `ecs_pay_log` values('133','121','448.00','0','0');");
E_D("replace into `ecs_pay_log` values('134','124','2214.00','0','0');");

require("../../inc/footer.php");
?>