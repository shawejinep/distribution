<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_distrib_sort`;");
E_C("CREATE TABLE `ecs_distrib_sort` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `money` decimal(10,2) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_distrib_sort` values('1','9.48','42','59');");
E_D("replace into `ecs_distrib_sort` values('2','4.74','41','59');");
E_D("replace into `ecs_distrib_sort` values('3','13.08','56','61');");
E_D("replace into `ecs_distrib_sort` values('4','586.56','56','66');");

require("../../inc/footer.php");
?>