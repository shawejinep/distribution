<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_oauth`;");
E_C("CREATE TABLE `ecs_weixin_oauth` (
  `oid` int(11) NOT NULL AUTO_INCREMENT,
  `weburl` varchar(200) NOT NULL,
  `click` int(11) NOT NULL,
  `id` int(11) NOT NULL COMMENT '分站ID',
  PRIMARY KEY (`oid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_oauth` values('1','http://jd.we10.cn/mobile/','206','0');");
E_D("replace into `ecs_weixin_oauth` values('2','http://jd.we10.cn/mobile/brand.php','20','0');");
E_D("replace into `ecs_weixin_oauth` values('3','http://jd.we10.cn/mobile/weixin/act.php?aid=1','33','0');");
E_D("replace into `ecs_weixin_oauth` values('4','http://jd.we10.cn/mobile/weixin/act.php?aid=2','40','0');");
E_D("replace into `ecs_weixin_oauth` values('5','http://jd.we10.cn/mobile/weixin/act.php?aid=3','41','0');");

require("../../inc/footer.php");
?>