<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_order_action`;");
E_C("CREATE TABLE `ecs_order_action` (
  `action_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `action_user` varchar(30) NOT NULL DEFAULT '',
  `order_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `action_place` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `action_note` varchar(255) NOT NULL DEFAULT '',
  `log_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`action_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_order_action` values('1','1','buyer','2','0','0','0','用户取消','1443389795');");
E_D("replace into `ecs_order_action` values('2','2','buyer','2','0','0','0','用户取消','1443389988');");
E_D("replace into `ecs_order_action` values('3','3','buyer','2','0','0','0','用户取消','1443390207');");
E_D("replace into `ecs_order_action` values('4','4','buyer','2','0','0','0','用户取消','1443390267');");
E_D("replace into `ecs_order_action` values('5','6','buyer','2','0','0','0','用户取消','1443390772');");
E_D("replace into `ecs_order_action` values('6','7','buyer','2','0','0','0','用户取消','1443405395');");
E_D("replace into `ecs_order_action` values('7','8','buyer','2','0','0','0','用户取消','1443405399');");
E_D("replace into `ecs_order_action` values('8','9','buyer','2','0','0','0','用户取消','1443405402');");
E_D("replace into `ecs_order_action` values('9','5','68ecshopxjd_cus','5','5','2','0','','1443475935');");
E_D("replace into `ecs_order_action` values('10','5','68ecshopxjd_cus','1','1','2','1','','1443475935');");
E_D("replace into `ecs_order_action` values('11','11','admin','1','0','0','0','fwef','1443482002');");
E_D("replace into `ecs_order_action` values('12','11','admin','1','0','2','0','fwefwe','1443482043');");
E_D("replace into `ecs_order_action` values('13','11','admin','5','5','2','0','','1443482053');");
E_D("replace into `ecs_order_action` values('14','11','admin','1','1','2','1','','1443482053');");
E_D("replace into `ecs_order_action` values('15','11','买家','5','2','2','0','','1443485998');");
E_D("replace into `ecs_order_action` values('17','14','buyer','2','0','0','0','用户取消','1443547786');");
E_D("replace into `ecs_order_action` values('18','16','admin','1','0','0','0','范围分为','1443554134');");
E_D("replace into `ecs_order_action` values('19','16','admin','1','0','2','0','范围分为','1443554309');");
E_D("replace into `ecs_order_action` values('20','16','admin','5','5','2','0','','1443554604');");
E_D("replace into `ecs_order_action` values('21','16','admin','1','1','2','1','','1443554604');");
E_D("replace into `ecs_order_action` values('22','16','买家','5','2','2','0','','1443554678');");
E_D("replace into `ecs_order_action` values('23','40','d b d n d n d n d n x','1','0','0','0','','1445391997');");
E_D("replace into `ecs_order_action` values('24','40','d b d n d n d n d n x','1','0','2','0','已付款','1445392017');");
E_D("replace into `ecs_order_action` values('25','40','','5','5','2','0','','1445392068');");
E_D("replace into `ecs_order_action` values('26','40','','1','1','2','1','','1445392068');");
E_D("replace into `ecs_order_action` values('27','40','买家','5','2','2','0','','1445476124');");
E_D("replace into `ecs_order_action` values('28','52','admin','1','0','0','0','','1445803640');");
E_D("replace into `ecs_order_action` values('29','56','buyer','2','0','0','0','用户取消','1445869387');");
E_D("replace into `ecs_order_action` values('30','59','admin','1','0','2','0','wewe','1449389082');");
E_D("replace into `ecs_order_action` values('31','59','admin','5','5','2','0','','1449389089');");
E_D("replace into `ecs_order_action` values('32','59','admin','1','1','2','1','','1449389089');");
E_D("replace into `ecs_order_action` values('33','59','admin','5','2','2','0','3333','1449389101');");
E_D("replace into `ecs_order_action` values('34','61','admin','1','0','2','0','1','1450773090');");
E_D("replace into `ecs_order_action` values('35','61','admin','5','5','2','0','','1450773100');");
E_D("replace into `ecs_order_action` values('36','61','admin','1','1','2','1','','1450773101');");
E_D("replace into `ecs_order_action` values('37','62','admin','1','0','2','0','11','1450813879');");
E_D("replace into `ecs_order_action` values('38','62','admin','5','5','2','0','','1450813887');");
E_D("replace into `ecs_order_action` values('39','62','admin','1','1','2','1','','1450813887');");
E_D("replace into `ecs_order_action` values('40','63','admin','1','0','2','0','222','1450814266');");
E_D("replace into `ecs_order_action` values('41','63','admin','5','5','2','0','','1450814326');");
E_D("replace into `ecs_order_action` values('42','63','admin','1','1','2','1','','1450814326');");
E_D("replace into `ecs_order_action` values('43','63','admin','5','5','2','0','','1450814365');");
E_D("replace into `ecs_order_action` values('44','63','admin','1','1','2','1','','1450814365');");
E_D("replace into `ecs_order_action` values('45','64','admin','1','0','2','0','111','1450814696');");
E_D("replace into `ecs_order_action` values('46','64','admin','5','5','2','0','','1450814703');");
E_D("replace into `ecs_order_action` values('47','64','admin','1','1','2','1','','1450814703');");
E_D("replace into `ecs_order_action` values('48','64','买家','5','2','2','0','','1450814704');");
E_D("replace into `ecs_order_action` values('49','65','admin','1','0','2','0','111','1450816051');");
E_D("replace into `ecs_order_action` values('50','65','admin','5','5','2','0','','1450816061');");
E_D("replace into `ecs_order_action` values('51','65','admin','1','1','2','1','','1450816061');");
E_D("replace into `ecs_order_action` values('52','65','admin','5','5','2','0','','1450816233');");
E_D("replace into `ecs_order_action` values('53','65','admin','1','1','2','1','','1450816233');");
E_D("replace into `ecs_order_action` values('54','65','admin','5','5','2','0','','1450816299');");
E_D("replace into `ecs_order_action` values('55','65','admin','1','1','2','1','','1450816299');");
E_D("replace into `ecs_order_action` values('56','65','admin','5','5','2','0','','1450816337');");
E_D("replace into `ecs_order_action` values('57','65','admin','1','1','2','1','','1450816337');");
E_D("replace into `ecs_order_action` values('58','65','admin','5','5','2','0','','1450816407');");
E_D("replace into `ecs_order_action` values('59','65','admin','1','1','2','1','','1450816407');");
E_D("replace into `ecs_order_action` values('60','65','admin','5','5','2','0','','1450816511');");
E_D("replace into `ecs_order_action` values('61','65','admin','1','1','2','1','','1450816511');");
E_D("replace into `ecs_order_action` values('62','65','admin','5','5','2','0','','1450816555');");
E_D("replace into `ecs_order_action` values('63','65','admin','1','1','2','1','','1450816555');");
E_D("replace into `ecs_order_action` values('64','65','admin','5','5','2','0','','1450816571');");
E_D("replace into `ecs_order_action` values('65','65','admin','1','1','2','1','','1450816571');");
E_D("replace into `ecs_order_action` values('66','65','买家','5','2','2','0','','1450816573');");
E_D("replace into `ecs_order_action` values('67','66','admin','1','0','2','0','111','1450817009');");
E_D("replace into `ecs_order_action` values('68','66','admin','5','5','2','0','','1450817017');");
E_D("replace into `ecs_order_action` values('69','66','admin','1','1','2','1','','1450817017');");
E_D("replace into `ecs_order_action` values('70','66','买家','5','2','2','0','','1450817019');");
E_D("replace into `ecs_order_action` values('71','67','admin','1','0','2','0','111','1450817424');");
E_D("replace into `ecs_order_action` values('72','67','admin','5','5','2','0','','1450817436');");
E_D("replace into `ecs_order_action` values('73','67','admin','1','1','2','1','','1450817436');");
E_D("replace into `ecs_order_action` values('74','67','admin','5','5','2','0','','1450817545');");
E_D("replace into `ecs_order_action` values('75','67','admin','1','1','2','1','','1450817545');");
E_D("replace into `ecs_order_action` values('76','67','admin','5','5','2','0','','1450817714');");
E_D("replace into `ecs_order_action` values('77','67','admin','1','1','2','1','','1450817714');");
E_D("replace into `ecs_order_action` values('78','67','admin','5','5','2','0','','1450818033');");
E_D("replace into `ecs_order_action` values('79','67','admin','1','1','2','1','','1450818033');");
E_D("replace into `ecs_order_action` values('80','67','admin','5','5','2','0','','1450818202');");
E_D("replace into `ecs_order_action` values('81','67','admin','1','1','2','1','','1450818202');");
E_D("replace into `ecs_order_action` values('82','67','admin','5','5','2','0','','1450818218');");
E_D("replace into `ecs_order_action` values('83','67','admin','1','1','2','1','','1450818218');");
E_D("replace into `ecs_order_action` values('84','67','admin','5','5','2','0','','1450818387');");
E_D("replace into `ecs_order_action` values('85','67','admin','1','1','2','1','','1450818387');");
E_D("replace into `ecs_order_action` values('86','67','admin','5','5','2','0','','1450818438');");
E_D("replace into `ecs_order_action` values('87','67','admin','1','1','2','1','','1450818438');");
E_D("replace into `ecs_order_action` values('88','67','admin','5','5','2','0','','1450818453');");
E_D("replace into `ecs_order_action` values('89','67','admin','1','1','2','1','','1450818453');");
E_D("replace into `ecs_order_action` values('90','67','admin','5','5','2','0','','1450818482');");
E_D("replace into `ecs_order_action` values('91','67','admin','1','1','2','1','','1450818482');");
E_D("replace into `ecs_order_action` values('92','67','买家','5','2','2','0','','1450818483');");
E_D("replace into `ecs_order_action` values('93','68','anan','1','0','2','0','222','1450819135');");
E_D("replace into `ecs_order_action` values('94','68','admin','5','5','2','0','','1450819146');");
E_D("replace into `ecs_order_action` values('95','68','admin','1','1','2','1','','1450819146');");
E_D("replace into `ecs_order_action` values('96','68','买家','5','2','2','0','','1450819146');");
E_D("replace into `ecs_order_action` values('97','69','anan','1','0','2','0','1111','1450819364');");
E_D("replace into `ecs_order_action` values('98','69','admin','5','5','2','0','','1450819371');");
E_D("replace into `ecs_order_action` values('99','69','admin','1','1','2','1','','1450819371');");
E_D("replace into `ecs_order_action` values('100','69','买家','5','2','2','0','','1450819375');");
E_D("replace into `ecs_order_action` values('101','70','anan','1','0','2','0','22','1450819863');");
E_D("replace into `ecs_order_action` values('102','70','anan','5','5','2','0','Wap端一键发货','1450820044');");
E_D("replace into `ecs_order_action` values('103','70','anan','1','1','2','1','Wap端一键发货','1450820044');");
E_D("replace into `ecs_order_action` values('104','71','anan','1','0','2','0','66','1450820560');");
E_D("replace into `ecs_order_action` values('105','71','anan','6','5','2','0','Wap端一键发货','1450820583');");
E_D("replace into `ecs_order_action` values('106','71','anan','1','4','2','1','Wap端一键发货','1450820583');");
E_D("replace into `ecs_order_action` values('107','71','anan','6','5','2','1','','1450820739');");
E_D("replace into `ecs_order_action` values('108','71','anan','6','5','2','1','','1450820791');");
E_D("replace into `ecs_order_action` values('109','72','anan','1','0','2','0','1111','1450821508');");
E_D("replace into `ecs_order_action` values('110','72','anan','5','5','2','0','Wap端一键发货','1450821548');");
E_D("replace into `ecs_order_action` values('111','72','anan','1','1','2','1','Wap端一键发货','1450821548');");
E_D("replace into `ecs_order_action` values('112','72','anan','5','5','2','0','Wap端一键发货','1450821572');");
E_D("replace into `ecs_order_action` values('113','72','anan','1','1','2','1','Wap端一键发货','1450821572');");
E_D("replace into `ecs_order_action` values('114','71','anan','5','5','2','0','','1450821707');");
E_D("replace into `ecs_order_action` values('115','71','','1','4','2','1','','1450821723');");
E_D("replace into `ecs_order_action` values('116','73','buyer','2','0','0','0','用户取消','1450899985');");
E_D("replace into `ecs_order_action` values('117','74','buyer','2','0','0','0','用户取消','1451000266');");
E_D("replace into `ecs_order_action` values('118','76','admin','1','0','0','0','','1451071198');");
E_D("replace into `ecs_order_action` values('119','76','admin','1','0','2','0','11','1451071209');");
E_D("replace into `ecs_order_action` values('120','76','admin','5','5','2','0','','1451071247');");
E_D("replace into `ecs_order_action` values('121','76','admin','1','1','2','1','','1451071247');");
E_D("replace into `ecs_order_action` values('122','76','买家','5','2','2','0','','1451071271');");
E_D("replace into `ecs_order_action` values('123','90','anan','1','0','0','0','','1451268711');");
E_D("replace into `ecs_order_action` values('124','90','anan','1','0','2','0','11','1451268721');");
E_D("replace into `ecs_order_action` values('125','90','','5','5','2','0','','1451268788');");
E_D("replace into `ecs_order_action` values('126','90','','1','1','2','1','','1451268788');");
E_D("replace into `ecs_order_action` values('127','90','买家','5','2','2','0','','1451268840');");
E_D("replace into `ecs_order_action` values('128','90','anan','5','2','2','0','[售后] 11','1451268938');");
E_D("replace into `ecs_order_action` values('129','100','admin','1','0','0','0','','1451515435');");
E_D("replace into `ecs_order_action` values('130','100','admin','1','3','0','0','','1451515450');");
E_D("replace into `ecs_order_action` values('131','100','admin','5','5','0','0','','1451515459');");
E_D("replace into `ecs_order_action` values('132','100','admin','1','1','0','1','','1451515474');");
E_D("replace into `ecs_order_action` values('133','100','admin','1','2','2','0','11','1451515549');");
E_D("replace into `ecs_order_action` values('134','100','admin','5','5','2','0','','1451515556');");
E_D("replace into `ecs_order_action` values('135','100','admin','1','1','2','1','','1451515556');");
E_D("replace into `ecs_order_action` values('136','100','买家','5','2','2','0','','1451515647');");
E_D("replace into `ecs_order_action` values('137','109','leilei','1','0','0','0','','1451882239');");
E_D("replace into `ecs_order_action` values('138','109','leilei','1','0','2','0','已付款','1451882257');");
E_D("replace into `ecs_order_action` values('139','109','','5','5','2','0','','1451882291');");
E_D("replace into `ecs_order_action` values('140','109','','1','1','2','1','','1451882291');");
E_D("replace into `ecs_order_action` values('141','108','admin','1','0','2','0','111','1451882386');");
E_D("replace into `ecs_order_action` values('142','124','buyer','2','0','0','0','用户取消','1456042746');");

require("../../inc/footer.php");
?>