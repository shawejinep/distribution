<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_keyword_area`;");
E_C("CREATE TABLE `ecs_keyword_area` (
  `access_time` int(10) unsigned NOT NULL DEFAULT '0',
  `w_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ip_address` varchar(15) NOT NULL DEFAULT '',
  `area` varchar(30) NOT NULL DEFAULT '',
  KEY `access_time` (`access_time`),
  KEY `w_id` (`w_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_keyword_area` values('1437586690','1','192.168.1.189','LAN');");
E_D("replace into `ecs_keyword_area` values('1437688030','2','192.168.1.162','LAN');");
E_D("replace into `ecs_keyword_area` values('1437688204','2','192.168.1.162','LAN');");
E_D("replace into `ecs_keyword_area` values('1437688209','2','192.168.1.162','LAN');");
E_D("replace into `ecs_keyword_area` values('1440115188','3','192.168.1.152','LAN');");
E_D("replace into `ecs_keyword_area` values('1440115201','4','192.168.1.152','LAN');");
E_D("replace into `ecs_keyword_area` values('1443554499','5','110.211.206.143','IANA');");
E_D("replace into `ecs_keyword_area` values('1443554546','6','110.211.206.143','IANA');");
E_D("replace into `ecs_keyword_area` values('1443582109','7','122.114.129.163','IANA');");
E_D("replace into `ecs_keyword_area` values('1443600797','7','157.55.39.167','IANA');");
E_D("replace into `ecs_keyword_area` values('1444984909','8','120.43.191.230','IANA');");
E_D("replace into `ecs_keyword_area` values('1444984922','9','120.43.191.230','IANA');");
E_D("replace into `ecs_keyword_area` values('1445797684','2','59.53.7.128','IANA');");
E_D("replace into `ecs_keyword_area` values('1450807025','10','101.226.168.221','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1451251266','11','116.52.3.226','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1451256204','7','101.226.167.236','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1451349666','12','123.4.53.57','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1451349674','12','123.4.53.57','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1451349679','12','123.4.53.57','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1451351286','12','123.4.53.57','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1451418768','7','203.208.60.141','[δ֪IP0801]');");
E_D("replace into `ecs_keyword_area` values('1455941868','10','182.118.22.207','[δ֪IP0801]');");

require("../../inc/footer.php");
?>