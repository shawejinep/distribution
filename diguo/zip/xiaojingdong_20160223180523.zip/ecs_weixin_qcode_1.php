<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_qcode`;");
E_C("CREATE TABLE `ecs_weixin_qcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL,
  `content` varchar(100) NOT NULL,
  `qcode` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_qcode` values('1','1','567','gQHd8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzZFejM0cERsRmkxdmV4VEk3R0NsAAIE+88aUwMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('2','2','1','gQFX8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0YwenV1WDdsSEMxbE1ldUE5V0NsAAIEVdAaUwMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('3','1','567','gQFz8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1RrejJCczNsR2kxalpMSWg3V0NsAAIELOMaUwMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('4','4','29','gQHm7joAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzl6dWt2VXZtbHF6dmZwZ3NzaGUzAAIEUqokVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('5','4','30','');");
E_D("replace into `ecs_weixin_qcode` values('6','4','33','');");
E_D("replace into `ecs_weixin_qcode` values('7','4','36','');");
E_D("replace into `ecs_weixin_qcode` values('8','4','0','');");
E_D("replace into `ecs_weixin_qcode` values('9','4','14','');");
E_D("replace into `ecs_weixin_qcode` values('10','4','43','');");
E_D("replace into `ecs_weixin_qcode` values('11','4','46','gQF/7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1B6Z0ZDLVhsZkFjRnJJbHIyQlRGAAIEN2Z5VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('12','4','50','gQFL7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzhUZ2FiT3ZsYlFjVUcwY0N4eFRGAAIECXF5VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('13','4','47','gQG37joAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2NUZ3N6UVRsVUFjcDFjZW84UlRGAAIEfnh5VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('14','4','56','gQF/7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0RqaFFBempsTFFkVVdMaG5qUlRGAAIEqXl5VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('15','4','58','gQEs8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL016Z3EwQWZsUXdjNmlZV2c5eFRGAAIEh/15VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('16','4','72','gQFQ7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzBUaXFURWJsM1Fla3RtY2lkeFRGAAIEW2zlVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('17','4','70','gQET8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3VUajNRSXJsaVFmd0hnOG5LaFRGAAIEt3fgVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('18','4','66','gQHD8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2dEaVVRUHpsM0FlbFVUWVJTUlRGAAIE5OngVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('19','4','','gQGQ8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzZqaWRTOEhsNHdlYURWd3NRQlRGAAIEZJTiVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('20','4','73','gQF27zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2VqanUzby1sbEFmdFJzeTlNeFRGAAIER1HkVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('21','4','75','gQHi8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL25UajhLT2psdVFmQU1DdDBJUlRGAAIEO43kVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('22','4','76','gQGg8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL09EaWFRU1hsMXdldU1ZNFZSeFRGAAIEtCTlVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('23','4','78','gQEy7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0FUaV9jc3psLXdlRzByY3FZeFRGAAIEa2vmVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('24','4','80','gQH/7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL096aDIwVHJsQ2dkenZZMjBxeFRGAAIErwx8VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('25','4','88','gQG58DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLy1UaDFkNnpsTUFkSlMwc3JxQlRGAAIE9IN8VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('26','4','93','gQGD7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3RqZzdXZTdsVndjdWJBQXM1aFRGAAIER_N8VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('27','4','74','gQFA8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1d6aWppeVhsNUFlZG1PM1ZmaFRGAAIEh0/sVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('28','4','90','gQHY7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2l6akx0NmZsakFmMTlqM3BGaFRGAAIEP1DsVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('29','4','100','gQEa8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0xEZzNYdXpsZEFjTjg1b0U2aFRGAAIEhY99VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('30','4','101','gQG58DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0pEZ2RZaVRsZEFjTkQ1SVN3QlRGAAIEz5l9VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('31','4','102','gQG87zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3ZUaGVLWmZsTGdkWGJndEFneFRGAAIEj/t9VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('32','4','106','gQG57zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2lEamkxX3JsbndmbTJENnpQeFRGAAIE/mfsVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('33','4','107','gQFA8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0h6aFplN0RsSmdkZnVha2RoQlRGAAIEw4J_VgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('34','4','109','gQEH8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1NEaXNVelhsX1FlQVEtNGZjUlRGAAIEAoDsVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('35','4','110','gQGc8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2h6aWQ5ei1sNUFlZElqR1hRQlRGAAIEd4DsVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('36','4','112','gQEd8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzlUajl0YlBsbEFmdG5rUEZJQlRGAAIEUQDtVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('37','4','113','gQFy8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3hqaWdrc0RsMUFldF9YRC1mUlRGAAIElKyAVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('38','4','49','gQHX8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzdUaWkyZXZsNWdlZnNsdUVmeFRGAAIEvNaAVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('39','4','119','gQGb8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3N6ajlPVC1sZ2dmNzJBVmZJQlRGAAIEo_6AVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('40','4','120','gQEj8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2NEaU9DdlhsOWdlUDRzWnJVeFRGAAIEDRDtVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('41','4','122','gQEX8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3p6akZkWlRsakFmMVEza2xHQlRGAAIEsguBVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('42','4','61','gQGl7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1dqamZNRmJsa0FmcFVleG1BaFRGAAIEe0CBVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('43','4','125','gQEb8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3JEamFBa3JscmdmWGlScHZCeFRGAAIErVeBVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('44','4','126','gQEA8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3BUano4SEhsaFFmOFNST2ZMaFRGAAIEgVqBVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('45','4','117','gQEZ8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2tUaWwzZXZsNEFlWnlpZUJlQlRGAAIEwdCBVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('46','4','128','gQFT8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1ZEamlUdzNsblFma2VfSXBQeFRGAAIEMeyBVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('47','4','130','gQEo8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0h6aVBLRkRsOXdlT0NxbEpVaFRGAAIECzftVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('48','4','131','gQHK8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0VEalhvc1Bsb0FmWkhLYk1DaFRGAAIE2zCCVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('49','4','134','gQFm8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0pqaTcwdnZsd2dlN1lwQ3laaFRGAAIEg5WCVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('50','4','136','gQEl7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3pEZ0FmX2psUndjX05ub2gzUlRGAAIERXMcVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('51','4','139','gQFQ8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzVUakYwd25saWdmelVsT0ZHQlRGAAIEzEztVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('52','4','141','gQHh7joAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2p6allNbmJsb1FmWXBqbFNCUlRGAAIEc3j2VQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('53','4','142','gQGr8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2pUaUtNMWZsX0FlQmhEdFlWeFRGAAIEUc6DVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('54','4','148','gQF98DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzhqak5haG5sdWdmRDdFUUVFQlRGAAIEyk7tVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('55','4','149','gQEW8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0RraHFtV2ZsQjlsX0dJTEdDR1FoAAIEqyeFVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('56','4','150','gQG67zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0NUanl5cGZsc3dmS09iX1NMeFRGAAIEgn7tVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('57','4','151','gQHa8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0hqakdtT1hsdmdmSERxajVHeFRGAAIExpDtVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('58','4','62','gQFA8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL05qamU5ZnZsb1FmWVZZQ1RBeFRGAAIEHjOGVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('59','4','154','gQF38DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzdEaU5RQnZsOGdlTDJsb21VQlRGAAIEIXeGVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('60','4','156','gQGr8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2tEaU5haUxsLUFlRnRTWUNVQlRGAAIEt7qGVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('61','4','157','gQGf7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0lUakRwcy1saHdmX0paZjdIaFRGAAIEOH7tVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('62','4','159','gQGI8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzlUakdGMHJsZ2dmN3hVTktHeFRGAAIEBfzzVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('63','4','160','gQGX8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzFEZ3N3ZXpsVVFjb2xHS2w4UlRGAAIEndUXVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('64','4','162','gQGm8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzBEajA3Mnpsc3dmS1BtYXhLUlRGAAIER5ntVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('65','4','168','gQHQ7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL25qaXNNMnZsMHdlcXF5aFZjUlRGAAIEbeiJVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('66','4','169','gQFL8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0lUaVRmOHZsN2dlWF9KY2JUaFRGAAIEYqXtVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('67','4','172','gQE18DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2V6akZVblRsa1Fmb01NMGZHQlRGAAIEIGGLVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('68','4','173','gQGY8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzRqaXV0dkxseEFlOXkxVEZjeFRGAAIE4aTtVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('69','4','177','gQHr8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0VUaUlZUEhsNVFlYzdhY1VWUlRGAAIES_6LVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('70','4','186','gQE08ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzZUaTk2YWJsLWdlSHkxX3pZQlRGAAIE4aztVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('71','4','189','gQHh8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1pqaVljUExsOWdlUGlkQUhSUlRGAAIEWZeMVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('72','4','188','gQHt8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzB6ak1LdXJsdlFmRWZtVkNFUlRGAAIExeuMVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('73','4','200','gQFO8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1lUanRlRWZsbFFmc005Y1pNQlRGAAIERwyNVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('74','4','199','gQEl8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2VEaTNuRDdsX2dlRHQ4N0lhaFRGAAIEUTzuVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('75','4','201','gQEJ7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzVqanp2cXZsamdmM25sRGFMaFRGAAIEfUHuVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('76','4','204','gQFW8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzlUaUN2Y3psOEFlSjZVUFdYeFRGAAIE90HuVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('77','4','207','gQEG8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL1p6alZsaUhsb1FmWXZkSDdDQlRGAAIEwK2wVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('78','4','208','');");
E_D("replace into `ecs_weixin_qcode` values('79','4','214','');");
E_D("replace into `ecs_weixin_qcode` values('80','4','222','');");
E_D("replace into `ecs_weixin_qcode` values('81','4','223','');");
E_D("replace into `ecs_weixin_qcode` values('82','4','224','gQHQ7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3NEalAxcWJscEFmZHJRYWtFaFRGAAIE13HuVQMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('83','4','225','gQGa8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3JEajVUTnZsaGdmLVZob3FKQlRGAAIEUoPJVgMEAAAAAA==');");
E_D("replace into `ecs_weixin_qcode` values('84','4','229','');");
E_D("replace into `ecs_weixin_qcode` values('85','4','231','');");
E_D("replace into `ecs_weixin_qcode` values('86','4','232','');");

require("../../inc/footer.php");
?>