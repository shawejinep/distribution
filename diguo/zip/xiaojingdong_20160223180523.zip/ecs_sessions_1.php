<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_sessions`;");
E_C("CREATE TABLE `ecs_sessions` (
  `sesskey` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `expiry` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adminid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `user_name` varchar(60) NOT NULL,
  `user_rank` tinyint(3) NOT NULL,
  `discount` decimal(3,2) NOT NULL,
  `email` varchar(60) NOT NULL,
  `data` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8");
E_D("replace into `ecs_sessions` values('297015c5c3f944f1c61562c4a2290a8f','1456221385','0','1','183.52.107.148','0','0','0.00','0','a:3:{s:10:\"admin_name\";s:5:\"admin\";s:11:\"action_list\";s:3:\"all\";s:10:\"last_check\";s:0:\"\";}');");
E_D("replace into `ecs_sessions` values('fe7cfcd4642c23d180a350ae13484735','1456221385','0','1','183.52.107.148','0','0','0.00','0','a:3:{s:10:\"admin_name\";s:5:\"admin\";s:11:\"action_list\";s:3:\"all\";s:10:\"last_check\";s:0:\"\";}');");
E_D("replace into `ecs_sessions` values('7a183d3053e5adfadc05643e58fab349','1456220929','0','0','180.153.214.178','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('69858aad38e996f308a385869cc2f72e','1456220926','0','0','120.86.47.86','0','0','1.00','0','a:4:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:13:\"captcha_login\";s:16:\"OTQwNTI3NDU0OQ==\";}');");
E_D("replace into `ecs_sessions` values('916fdc8d0c9478f4520b391086f84abd','1456220918','0','0','180.153.214.198','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('f676ee47964144be65eab9c0d20125a4','1456220929','0','0','118.114.92.185','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ddedb609c255901b4f44fe4073fdf298','1456220814','0','0','180.153.163.190','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('698ee6866573d8e60a50109c1bef449f','1456220813','0','0','180.153.201.15','0','0','1.00','0','a:4:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"flow_type\";i:0;}');");
E_D("replace into `ecs_sessions` values('5c398e9605de233cc60a14348172b4d8','1456220806','0','0','101.226.33.203','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('44c47597e08c73090a265a607a885ed6','1456220806','0','0','101.226.33.203','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('9566d64a9f64dcb42cd3942cc8f36ae5','1456220598','0','0','120.86.242.48','0','0','1.00','0','a:4:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:13:\"captcha_login\";s:16:\"ZWZjNzMwYzViNA==\";}');");
E_D("replace into `ecs_sessions` values('effa787f67539492e12c8334bf4ccf5c','1456220795','0','0','180.153.214.197','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ebfb807c6df6018e550ef8e17e9ea458','1456220794','0','0','180.153.214.197','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('99cbdccf192a51a1086eb6b396815ef7','1456220826','0','0','118.114.92.185','0','0','1.00','0','a:7:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:13:\"captcha_login\";s:16:\"OWFmZjg0YjY1Mw==\";s:9:\"flow_type\";i:0;s:19:\"one_step_buy_rec_id\";i:289;s:13:\"sel_cartgoods\";s:3:\"289\";}');");

require("../../inc/footer.php");
?>