<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_menu`;");
E_C("CREATE TABLE `ecs_weixin_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `value` varchar(200) NOT NULL,
  `order` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_menu` values('1','0','进入商城','2','http://jd.we10.cn/mobile/','100');");
E_D("replace into `ecs_weixin_menu` values('3','0','我的地盘','1','','99');");
E_D("replace into `ecs_weixin_menu` values('4','0','更多','1','','0');");
E_D("replace into `ecs_weixin_menu` values('12','3','分销中心','2','http://jd.we10.cn/mobile/v_user.php','3');");
E_D("replace into `ecs_weixin_menu` values('20','3','我的二维码','1','qrcode','0');");
E_D("replace into `ecs_weixin_menu` values('14','3','会员中心','2','http://jd.we10.cn/mobile/user.php','4');");
E_D("replace into `ecs_weixin_menu` values('15','4','今日签到','1','qd','1');");
E_D("replace into `ecs_weixin_menu` values('16','4','多客服咨询','1','kf','2');");
E_D("replace into `ecs_weixin_menu` values('17','4','砸金蛋','2','http://jd.we10.cn/mobile/weixin/oauth.php?id={id}&oid=3','3');");
E_D("replace into `ecs_weixin_menu` values('18','4','大转盘','2','http://jd.we10.cn/mobile/weixin/oauth.php?id={id}&oid=5','5');");
E_D("replace into `ecs_weixin_menu` values('19','4','刮一刮','2','http://jd.we10.cn/mobile/weixin/oauth.php?id={id}&oid=4','4');");
E_D("replace into `ecs_weixin_menu` values('21','3','游戏中心','2','http://youxi.we10.cn/','0');");

require("../../inc/footer.php");
?>