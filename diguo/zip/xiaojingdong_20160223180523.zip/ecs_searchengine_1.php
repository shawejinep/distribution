<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_searchengine`;");
E_C("CREATE TABLE `ecs_searchengine` (
  `date` date NOT NULL DEFAULT '0000-00-00',
  `searchengine` varchar(20) NOT NULL DEFAULT '',
  `count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`,`searchengine`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_searchengine` values('2015-09-29','GOOGLE','1');");
E_D("replace into `ecs_searchengine` values('2015-09-30','GOOGLE','1');");
E_D("replace into `ecs_searchengine` values('2015-12-23','SOGOU','2');");
E_D("replace into `ecs_searchengine` values('2015-12-24','GOOGLE','1614');");
E_D("replace into `ecs_searchengine` values('2015-12-24','SOGOU','1');");
E_D("replace into `ecs_searchengine` values('2015-12-25','SOGOU','2');");
E_D("replace into `ecs_searchengine` values('2015-12-25','GOOGLE','1960');");
E_D("replace into `ecs_searchengine` values('2015-12-26','GOOGLE','301');");
E_D("replace into `ecs_searchengine` values('2015-12-26','SOGOU','1');");
E_D("replace into `ecs_searchengine` values('2015-12-27','GOOGLE','396');");
E_D("replace into `ecs_searchengine` values('2015-12-27','SOGOU','2');");
E_D("replace into `ecs_searchengine` values('2015-12-28','GOOGLE','379');");
E_D("replace into `ecs_searchengine` values('2015-12-28','SOGOU','1');");
E_D("replace into `ecs_searchengine` values('2015-12-29','GOOGLE','392');");
E_D("replace into `ecs_searchengine` values('2015-12-29','SOGOU','3');");
E_D("replace into `ecs_searchengine` values('2015-12-30','GOOGLE','404');");
E_D("replace into `ecs_searchengine` values('2015-12-31','GOOGLE','162');");
E_D("replace into `ecs_searchengine` values('2016-01-05','SOGOU','1');");
E_D("replace into `ecs_searchengine` values('2016-02-17','GOOGLE','365');");
E_D("replace into `ecs_searchengine` values('2016-02-18','GOOGLE','453');");
E_D("replace into `ecs_searchengine` values('2016-02-19','GOOGLE','366');");
E_D("replace into `ecs_searchengine` values('2016-02-19','SOGOU','3');");
E_D("replace into `ecs_searchengine` values('2016-02-20','GOOGLE','527');");
E_D("replace into `ecs_searchengine` values('2016-02-20','SOGOU','5');");
E_D("replace into `ecs_searchengine` values('2016-02-21','GOOGLE','618');");
E_D("replace into `ecs_searchengine` values('2016-02-21','SOGOU','11');");
E_D("replace into `ecs_searchengine` values('2016-02-22','GOOGLE','4');");
E_D("replace into `ecs_searchengine` values('2016-02-22','SOGOU','2');");
E_D("replace into `ecs_searchengine` values('2016-02-23','GOOGLE','34');");

require("../../inc/footer.php");
?>