<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxch_qr_tianxin100`;");
E_C("CREATE TABLE `wxch_qr_tianxin100` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `qr_path` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `scene_id` int(11) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8");
E_D("replace into `wxch_qr_tianxin100` values('1','1451297650.jpg','0','0','人生几何');");
E_D("replace into `wxch_qr_tianxin100` values('2','1451297715.jpg','122','41','人生几何');");
E_D("replace into `wxch_qr_tianxin100` values('3','1451299582.jpg','112','0','吴帅');");
E_D("replace into `wxch_qr_tianxin100` values('4','1451303582.jpg','74','0','别管我、');");
E_D("replace into `wxch_qr_tianxin100` values('5','1451307203.jpg','66','0','小君');");
E_D("replace into `wxch_qr_tianxin100` values('6','1451317165.jpg','125','43','『雲淡風輕』');");
E_D("replace into `wxch_qr_tianxin100` values('7','1451324109.jpg','110','0','袁辉');");
E_D("replace into `wxch_qr_tianxin100` values('8','1451354612.jpg','88','0','闫兵');");
E_D("replace into `wxch_qr_tianxin100` values('9','1451359107.jpg','126','0','博仔');");
E_D("replace into `wxch_qr_tianxin100` values('10','1451367404.jpg','130','47','凯');");
E_D("replace into `wxch_qr_tianxin100` values('11','1451398532.jpg','134','49','非煤老板');");
E_D("replace into `wxch_qr_tianxin100` values('12','1451453924.jpg','139','51','我，隐形人');");
E_D("replace into `wxch_qr_tianxin100` values('13','1451478612.jpg','142','53','Tina');");
E_D("replace into `wxch_qr_tianxin100` values('14','1451549257.jpg','148','54','普天同庆');");
E_D("replace into `wxch_qr_tianxin100` values('15','1451549257.jpg','148','0','普天同庆');");
E_D("replace into `wxch_qr_tianxin100` values('16','1451567019.jpg','149','55','小君');");
E_D("replace into `wxch_qr_tianxin100` values('17','1451569526.jpg','150','56','建华传媒');");
E_D("replace into `wxch_qr_tianxin100` values('18','1451586932.jpg','72','0','品茶修心 坐而论道-我是密谋茶馆');");
E_D("replace into `wxch_qr_tianxin100` values('19','1451652909.jpg','154','0','亮亮');");
E_D("replace into `wxch_qr_tianxin100` values('20','1451670199.jpg','156','60','城城carson');");
E_D("replace into `wxch_qr_tianxin100` values('21','1451704408.jpg','157','61','黑蚁网络＆肖锐');");
E_D("replace into `wxch_qr_tianxin100` values('22','1451723063.jpg','159','0','空寻气的鱼');");
E_D("replace into `wxch_qr_tianxin100` values('23','1451724498.jpg','160','63','灵异');");
E_D("replace into `wxch_qr_tianxin100` values('24','1451737187.jpg','162','0','Dichen');");
E_D("replace into `wxch_qr_tianxin100` values('25','1451976573.jpg','49','0','路振东');");
E_D("replace into `wxch_qr_tianxin100` values('26','1451997151.jpg','173','68','sjm.life.‍莫');");
E_D("replace into `wxch_qr_tianxin100` values('27','1455726060.jpg','189','0','a孟召臣');");
E_D("replace into `wxch_qr_tianxin100` values('28','1455873355.jpg','199','0','天随人愿');");
E_D("replace into `wxch_qr_tianxin100` values('29','1455873506.jpg','200','0','风云天下');");

require("../../inc/footer.php");
?>