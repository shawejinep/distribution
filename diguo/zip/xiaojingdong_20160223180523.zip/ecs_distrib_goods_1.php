<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_distrib_goods`;");
E_C("CREATE TABLE `ecs_distrib_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `distrib_time` int(2) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `distrib_money` decimal(10,2) NOT NULL,
  `distrib_type` int(2) NOT NULL,
  `goods_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");

require("../../inc/footer.php");
?>