<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_login`;");
E_C("CREATE TABLE `ecs_weixin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createtime` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `token` varchar(200) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `value` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_login` values('85','1456051999','0','gQEr8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3FqaVF3eUxsMXdldUpCNmRUUmJGAAIEH5fJVgMEWAIAAA==','113.140.43.54','519994991');");
E_D("replace into `ecs_weixin_login` values('84','1455982152','0','gQF38DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0l6aU42alhsOHdlS2s1ZU5VQmJGAAIESYbIVgMEWAIAAA==','111.37.29.129','821529485');");
E_D("replace into `ecs_weixin_login` values('83','1455883768','0','gQGx7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0tEalpoYnJscndmV2VKenFCQmJGAAIE_QXHVgMEWAIAAA==','61.145.35.140','837689110');");
E_D("replace into `ecs_weixin_login` values('82','1455872107','0','gQE18DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL01UaWVFV1RsNmdlVEs0VjhReGJGAAIEa9jGVgMEWAIAAA==','211.103.255.3','721075516');");
E_D("replace into `ecs_weixin_login` values('81','1455868744','49','gQH07zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0h6ajlIdHJsandmMnRLdDFJQmJGAAIEScvGVgMEWAIAAA==','211.103.255.3','687449205');");
E_D("replace into `ecs_weixin_login` values('80','1455868721','0','gQEk8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLzJ6amJRVDdscWdmVHkyOHBCaGJGAAIEMcvGVgMEWAIAAA==','180.153.214.176','687218882');");
E_D("replace into `ecs_weixin_login` values('79','1455868721','0','gQGJ8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0ZqaTVfdzNsMFFlb2o2S0taQmJGAAIEMcvGVgMEWAIAAA==','180.153.4.19','687213256');");
E_D("replace into `ecs_weixin_login` values('78','1455868721','0','gQER8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3ZqalpXMzNscVFmUTl3b3lCQmJGAAIEMcvGVgMEWAIAAA==','14.17.34.190','687214661');");
E_D("replace into `ecs_weixin_login` values('77','1455868704','0','gQEm8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2hUaVBxTjdsNXdlZW5ESFpVaGJGAAIEIMvGVgMEWAIAAA==','61.145.35.140','687042012');");
E_D("replace into `ecs_weixin_login` values('76','1455868068','0','gQEe8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xLy1UaWxJZkRsOEFlSlEwbHRlQmJGAAIEpMjGVgMEWAIAAA==','61.145.35.140','680681886');");
E_D("replace into `ecs_weixin_login` values('75','1455868058','0','gQGw8DoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0hUai1Yb3JsZ1FmNHBxazVJaGJGAAIEm8jGVgMEWAIAAA==','61.145.35.140','680587735');");

require("../../inc/footer.php");
?>