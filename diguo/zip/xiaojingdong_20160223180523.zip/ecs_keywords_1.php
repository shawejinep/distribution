<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_keywords`;");
E_C("CREATE TABLE `ecs_keywords` (
  `date` date NOT NULL DEFAULT '0000-00-00',
  `searchengine` varchar(20) NOT NULL DEFAULT '',
  `keyword` varchar(90) NOT NULL DEFAULT '',
  `count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`,`searchengine`,`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_keywords` values('2015-09-30','ecshop','请输入关键词','1');");
E_D("replace into `ecs_keywords` values('2015-10-22','ecshop','连衣裙','1');");
E_D("replace into `ecs_keywords` values('2015-12-07','ecshop','韩国进口X-5花生夹心巧克力棒盒装（24根）864g','1');");
E_D("replace into `ecs_keywords` values('2015-12-23','ecshop','车','4');");
E_D("replace into `ecs_keywords` values('2015-12-24','ecshop','奇居','1');");
E_D("replace into `ecs_keywords` values('2015-12-24','ecshop','可爱卡通','1');");
E_D("replace into `ecs_keywords` values('2015-12-24','ecshop','康庄素道','1');");
E_D("replace into `ecs_keywords` values('2015-12-25','ecshop','T恤','1');");
E_D("replace into `ecs_keywords` values('2015-12-28','ecshop','炫迈','2');");
E_D("replace into `ecs_keywords` values('2015-12-28','ecshop','T恤','1');");
E_D("replace into `ecs_keywords` values('2015-12-30','ecshop','猫熊','5');");
E_D("replace into `ecs_keywords` values('2015-12-30','ecshop','女装','1');");
E_D("replace into `ecs_keywords` values('2015-12-31','ecshop','小碎花','1');");
E_D("replace into `ecs_keywords` values('2015-12-31','ecshop','阿迪达斯','1');");
E_D("replace into `ecs_keywords` values('2015-12-31','ecshop','水果盘','3');");
E_D("replace into `ecs_keywords` values('2016-01-03','ecshop','T恤','1');");
E_D("replace into `ecs_keywords` values('2016-01-03','ecshop','护肤','1');");
E_D("replace into `ecs_keywords` values('2016-01-05','ecshop','雅诗兰黛','1');");
E_D("replace into `ecs_keywords` values('2016-02-19','ecshop','三星','9');");
E_D("replace into `ecs_keywords` values('2016-02-19','ecshop','天天','2');");
E_D("replace into `ecs_keywords` values('2016-02-20','ecshop','阿迪达斯','1');");
E_D("replace into `ecs_keywords` values('2016-02-20','ecshop','T恤','1');");
E_D("replace into `ecs_keywords` values('2016-02-21','ecshop','T恤','1');");
E_D("replace into `ecs_keywords` values('2016-02-21','ecshop','小碎花','1');");
E_D("replace into `ecs_keywords` values('2016-02-21','ecshop','阿迪达斯','1');");
E_D("replace into `ecs_keywords` values('2016-02-21','ecshop','药品','1');");
E_D("replace into `ecs_keywords` values('2016-02-21','ecshop','保健品','1');");
E_D("replace into `ecs_keywords` values('2016-02-21','ecshop','护肤','1');");

require("../../inc/footer.php");
?>