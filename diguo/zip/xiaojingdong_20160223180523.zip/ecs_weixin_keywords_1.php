<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_weixin_keywords`;");
E_C("CREATE TABLE `ecs_weixin_keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(30) NOT NULL,
  `keys` varchar(100) NOT NULL,
  `jf_type` int(11) NOT NULL,
  `jf_num` int(11) NOT NULL,
  `jf_maxnum` int(11) NOT NULL,
  `keyname` varchar(100) NOT NULL,
  `clicks` int(11) NOT NULL,
  `diy_type` int(11) NOT NULL,
  `diy_value` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_weixin_keywords` values('1','联系','电话','0','0','0','联系方式','6','1','article_131');");
E_D("replace into `ecs_weixin_keywords` values('2','123','111','0','0','0','测试','2','1','article_132');");
E_D("replace into `ecs_weixin_keywords` values('3','图文1','文图1','0','0','0','图文测试','2','2','article_133');");
E_D("replace into `ecs_weixin_keywords` values('4','测试','测试','0','0','0','测试','1','1','article_134');");

require("../../inc/footer.php");
?>