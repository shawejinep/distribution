<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `weixin_login`;");
E_C("CREATE TABLE `weixin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createtime` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `token` varchar(200) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `value` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `weixin_login` values('1','1450798107','0','gQFI7joAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3lEbGF4Q3JsRmZwc2VRZGV6QmREAAIEG2x5VgMEWAIAAA==','183.2.65.79','981074541');");

require("../../inc/footer.php");
?>