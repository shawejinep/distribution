<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_sessions`;");
E_C("CREATE TABLE `ecs_sessions` (
  `sesskey` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `expiry` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adminid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `user_name` varchar(60) NOT NULL,
  `user_rank` tinyint(3) NOT NULL,
  `discount` decimal(3,2) NOT NULL,
  `email` varchar(60) NOT NULL,
  `data` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_sessions` values('b8eb03808355cbb896967064bab3c62f','1457340963','0','0','115.29.142.137','0','0','0.00','0','a:1:{s:10:\"last_check\";i:1457312163;}');");
E_D("replace into `ecs_sessions` values('2adf217f305227065a2323f6722fcd58','1457339490','0','0','51.255.65.82','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('fc090ea24f8c3a8f5444f0edf7a1ba5b','1457339758','0','0','51.255.65.89','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('9e329664f50012882e0eb8cd0b83ae56','1457340367','0','0','51.255.65.95','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('c11ff9990d1c756752248b6458922fb1','1457340448','0','0','51.255.65.89','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('44e0e27c158bd0854d4497c8cbe87c3f','1457340746','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('6050caee7b7d9911b6ea1acead8d6401','1457340746','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('cacfcd103449ca4e05ce4123203863bb','1457340471','0','0','51.255.65.3','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('69a5481911a9ace9283a968a40e8a3ec','1457340619','0','0','51.255.65.65','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7b01933b328f9480b535fcf61e42c327','1457340621','0','0','51.255.65.53','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('5b47827c2d25330422320630d6625702','1457340741','4658','0','223.104.94.9','tianxin4658','1','1.00','0','a:6:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"wechat_id\";s:28:\"oJrn5sq1ozTIunW75F7hryO2Kptw\";s:9:\"last_time\";s:10:\"1457103954\";s:7:\"last_ip\";s:13:\"220.197.195.5\";}');");
E_D("replace into `ecs_sessions` values('706f97b5ef0f2dbebb048244f58c35e1','1457340746','0','0','101.226.62.80','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('778412d6fe4c8ddbabe6e5a1eca38518','1457340743','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('966b8f885bf533c1c3e96526db614bbf','1457340747','0','0','101.226.62.80','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('fcf3ff4b0c092d01d362ce9e240497ea','1457340744','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ef7d0171986571a01cddec5410d6fffa','1457340747','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('231ca740eeac6fc83dd77829cc32016c','1457340752','0','0','101.226.62.80','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('147532784a8e074681af8664e6aa4acf','1457340750','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ca2fa8f5973521334c6c39b5f5df6c04','1457340751','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('3666de378fb7e65f1613bef6d9318844','1457340752','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('777179fd121edff71e4fc95ff78d9c58','1457340955','5201','0','117.136.75.221','tianxin5201','0','1.00','0','a:4:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:13:\"singlemessage\";s:10:\"login_fail\";i:0;s:9:\"wechat_id\";s:28:\"oJrn5suH7O0-R94hzAw8IA0Ci748\";}');");
E_D("replace into `ecs_sessions` values('81a77daa45f31952bf833c0ad44ead83','1457340789','0','0','163.177.82.13','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('eea8ec58a847f74947a01736e0d49738','1457340789','0','0','183.232.118.13','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('eeaaf010321d8a20a79053d33fcb7ad3','1457340815','0','0','51.255.65.53','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('35153c2c52f56e02be649a84df943e15','1457340969','0','0','178.255.215.90','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('5c1c12f420c351253294d464cf54abc5','1457341056','0','0','51.255.65.50','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('00c640781e505c8a0dce0973df551f95','1457340745','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('cef847288b872326e671b65bacc648e2','1457340848','0','0','221.237.115.189','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('99b6763dae8b31f0a32d31bfe4da533a','1457340966','0','0','178.255.215.90','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('417dd9b05bc4b32980d497951b6108cb','1457340963','0','0','178.255.215.90','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:28;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ae0e91237349e46ce211badd9dd0be8c','1457339318','0','0','51.255.65.49','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('a03fe132d54b26705fff0f534930ed0f','1457339317','0','0','51.255.65.19','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('4996a2c427f16685b854c77c88943fb9','1457339340','0','0','101.226.62.82','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('54145e65855c505ee8371064e17af8cc','1457339338','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('de4086e1c140e386f545e8878ad42af5','1457339340','0','0','115.29.142.137','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('d5851eb42d258ce28243049794103bc6','1457339450','0','0','51.255.65.97','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('9e15107bfe90ebb2bea094f000a7d3f1','1457339926','0','0','51.255.65.30','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('6a19c6ff8ee00d66bedd8e9465bd6c9e','1457339692','0','0','51.255.65.27','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('278d7446a71deea918332a062db4776d','1457339913','0','0','51.255.65.56','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b6b0c1e5190dbe55cfa0c8642654686d','1457339944','0','0','51.255.65.8','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('bf45235e4d4a0ff7810ffc61f9f509ac','1457339978','0','0','51.255.65.81','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('869bf9b6e5f65ce93e448698bb27a90e','1457340023','0','0','51.255.65.23','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('2720379cb3a0d73a7443fa1a0ce04f4a','1457340070','0','0','51.255.65.33','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('f312541f48bc1ea3efe8ff73a29d059a','1457340350','0','0','51.255.65.74','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");

require("../../inc/footer.php");
?>