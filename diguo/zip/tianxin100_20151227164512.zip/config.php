<?php
	$b_table="ecs_admin_user";
	$tb[ecs_admin_user]=1;

	$b_baktype=0;
	$b_filesize=300;
	$b_bakline=500;
	$b_autoauf=1;
	$b_dbname="tianxin100";
	$b_stru=1;
	$b_strufour=0;
	$b_dbchar="auto";
	$b_beover=0;
	$b_insertf="replace";
	$b_autofield=",,";
	$b_bakdatatype=0;
	?>