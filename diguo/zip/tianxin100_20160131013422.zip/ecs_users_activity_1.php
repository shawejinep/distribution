<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_users_activity`;");
E_C("CREATE TABLE `ecs_users_activity` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_nickname` varchar(200) NOT NULL,
  `user_head` varchar(200) NOT NULL,
  `act_id` mediumint(8) NOT NULL,
  `act_type` tinyint(3) NOT NULL,
  `shop_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `new_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `activity_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_times` int(10) unsigned NOT NULL DEFAULT '0',
  `is_finished` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_users_activity` values('1','4246','吴帅','http://wx.qlogo.cn/mmopen/ajNVdqHZLLDcEqQ1yFlQx0mDaic1kV7VQ82kpF8X1DwcA2BPS3HVhd3w0sWas0s3uxZN97wuCRicHrksQXjPjqaQ/0','24','5','20.00','17.68','1453949924','0','0');");
E_D("replace into `ecs_users_activity` values('2','4420','VV朋友圈助手','','24','5','20.00','20.00','1453961486','0','0');");
E_D("replace into `ecs_users_activity` values('3','4373','随风潜','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tMkmiaSrJ0aZ4MP6KsP2K5JSZbTYIgZictbGvwxB76XBNlP2YKky4xMR9zLzYUfqFticKwAFRGkaX8uvrwIjhsCmm/0','24','5','20.00','20.00','1453961541','0','0');");
E_D("replace into `ecs_users_activity` values('4','4272','建华传媒','http://wx.qlogo.cn/mmopen/2qmw3N1fBBOHrHicE7v6TicjT1lcUdia6pYaEf3v0lljHLIS3jPibGWJAL6jojB4SibMXuT6XQ7p0Qy403Aq353kt3ic0VCy3iboTq1/0','24','5','20.00','18.05','1453962029','0','0');");
E_D("replace into `ecs_users_activity` values('5','4696','在一起','http://wx.qlogo.cn/mmopen/2KjiaxU8ZEl4xHiczdqdNVL9xyicWF8eoBrpdZvjzOibibs27E4CRLYY3Pk56UbJl1jCHCV2HusFgzPxsviapkHNLZb6H7g1hejk06/0','24','5','20.00','15.68','1453962196','0','0');");
E_D("replace into `ecs_users_activity` values('6','4699','。Cui mohan','http://wx.qlogo.cn/mmopen/ib7Efy61IoTCJ1zrNiaxGERR7qzN6W6CG4ZlBxFRmVIQheV1UjTcS6LpaqMLp2SoWTb8fO4KOPhebW8pHTraG5SvbicTvtf2K8ic/0','24','5','20.00','20.00','1453962915','0','0');");
E_D("replace into `ecs_users_activity` values('7','4275','A阿华','http://wx.qlogo.cn/mmopen/9OakAVM0cSbPrdgtx9ekT3Ha8cHiaibMvuQWbKmSK6IicH4Kw6ibkLCOJxk435u8pDiciczYKI1DfxgzdcgT7MAw1iaLcaibFnibCZiaVn/0','24','5','20.00','11.49','1453963385','0','0');");
E_D("replace into `ecs_users_activity` values('8','4284','王美佳','http://wx.qlogo.cn/mmopen/ib7Efy61IoTC0uP7zicroPrVyuFh9CiaDZKOp0MK0w2Jibcwe5doibXDy7p6b6o0AtzyfQeIDciaDc5JY6Aps3606XQrZ88PU2uyTt/0','24','5','20.00','14.09','1453963567','0','0');");
E_D("replace into `ecs_users_activity` values('9','4565','刘义桥大师弟子·兰江宁','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tvaesBDEgGdP08Nbpz9eZDx5WNnWHL9JromPBNVYRKrIN9DPibnfORSM4MZ8IY1o72DHLt8GBJBHmPOVib7hjGXa/0','24','5','20.00','15.84','1453963569','0','0');");
E_D("replace into `ecs_users_activity` values('10','4651','洛辰-日本代购、留学','http://wx.qlogo.cn/mmopen/2KjiaxU8ZEl7MMmUfJtPwZ3s8UuqnRTahVuLnLHS5kTUfCwjw1UuQZT25UhaEhluc7mvLJica7vbunUaTmibkOXDC0nialKKp5ud/0','24','5','20.00','18.11','1453963928','0','0');");
E_D("replace into `ecs_users_activity` values('11','4703','车明亮','http://wx.qlogo.cn/mmopen/PiajxSqBRaEJibhClFlsRKVxkULBbqv3yxicyaqyZM8ujNrdhbmDjCHkXB7VwUuStLX1Pj3vPhoqh3oibVwMF9veDA/0','24','5','20.00','17.72','1453963972','0','0');");
E_D("replace into `ecs_users_activity` values('12','4680','蒙仕杰~爱才通公司','http://wx.qlogo.cn/mmopen/ib7Efy61IoTCa81PxgXjKC9wNWGuXjqyrttrLC942lKzop2mCoibtFrdkfPYIqmLW5rf68Cs4sEeic4f0AcicCibE9YDHyH4TebCH/0','24','5','20.00','16.85','1453964305','0','0');");
E_D("replace into `ecs_users_activity` values('13','4298','周明生','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tMkmiaSrJ0aZicvbZFXzvQGITksicoBQqStE00ia3ibk2oZna857Zicajch18SJnrPbwNicvSPQ6zXUuichxn2CmY612u2/0','24','5','20.00','17.67','1453965474','0','0');");
E_D("replace into `ecs_users_activity` values('14','4663','无界智慧金融--鱼涛','http://wx.qlogo.cn/mmopen/PiajxSqBRaEJ6UCgIBVO5NEaj24wibUySQ7e10mlicKiaCYIfOY49RdmpLxx2WmFoWO58ReAtXBYqhV0mibkjo0cxRw/0','24','5','20.00','15.44','1453966816','0','0');");
E_D("replace into `ecs_users_activity` values('15','4674','小于哥','http://wx.qlogo.cn/mmopen/ZMdxSDafpxTC1v2Yibiau0EMz4gklJV8j8Z8ee6Bibxpa6A4tlWy16napA4tUibu6mwTuYibuT5ZNtEc3aqL5uYrRlnVtnIS0T8eD/0','24','5','20.00','18.82','1453967853','0','0');");
E_D("replace into `ecs_users_activity` values('16','4225','巨匠 微信超級會員','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6uY6ibwUq4koibQyXd5RsVr0h6UsrayHrR1bET5VW99cVgqcicDn7tU6TTxD2h22kgW1HvT4TbXZyfc71HevdEfH0F/0','24','5','20.00','18.02','1453968864','0','0');");
E_D("replace into `ecs_users_activity` values('17','4722','徐骏杰','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tMkmiaSrJ0aZ8KCTe24l6pIEVxmd5JL3tNG8gZ5d2CAGfF2g8ZwYtf7tyYOsBwCWKN5hZr0icZ7mnDAznFmmMCab/0','24','5','20.00','16.81','1453969140','0','0');");
E_D("replace into `ecs_users_activity` values('18','4404','平凡的人','http://wx.qlogo.cn/mmopen/ZMdxSDafpxRVdbUja4umKfiahhiaZiaf2Tib5ibdW8oBg0ic2a4pz9C3YcpMzhcwmFhnpMN7MpMZGPAaxhq5Z3aU29rw/0','24','5','20.00','18.82','1453970999','0','0');");
E_D("replace into `ecs_users_activity` values('19','4725','艾歌','http://wx.qlogo.cn/mmopen/ZMdxSDafpxTC1v2Yibiau0EHicpMiano0oUdWCUd4NGTZzwj9mZFLibkggPFzZ5d5OzMFLAcqa3RAusZGFia8txmicTeBOvOkWibv6xT/0','24','5','20.00','18.80','1453971511','0','0');");
E_D("replace into `ecs_users_activity` values('20','4659','a金刚','http://wx.qlogo.cn/mmopen/ajNVdqHZLLAibpyQrbVfdLkuia6FsE36UFJiac0ZfTwv8ThDPxllY7mdXxw8xEv6nAibspnhtBjSkm9z4omsyuD8eg/0','24','5','20.00','14.22','1453973416','0','0');");
E_D("replace into `ecs_users_activity` values('21','4630','【51魟鱼网】51hongyu.com','http://wx.qlogo.cn/mmopen/MDujI20ZrCUjqjibiammfEzK9HcRtZ5hv5bkAhRTuTaicsKoA6HrYgXyepz7Zo7Ew5ePJxQTB2Cnfu2ZNeokyBWr6ugTywzpeJz/0','24','5','20.00','17.70','1453973818','0','0');");
E_D("replace into `ecs_users_activity` values('22','4677','品茶修心 坐而论道-我是密谋茶馆','http://wx.qlogo.cn/mmopen/ZMdxSDafpxTC1v2Yibiau0EEOWJoCLcj67MhOib5qe2FPBNNCf4FNjibWHiaHSibKr9uTx4jfDDXQzr9KFQxsicniaZrTbZzCX6ib7cXs/0','24','5','20.00','16.34','1453976725','0','0');");
E_D("replace into `ecs_users_activity` values('23','4737','兰色姿恋','http://wx.qlogo.cn/mmopen/Q3auHgzwzM59t54x0WO4DC6SVhwicJpfjjJLrMWpTpzVbBHClc8gc4ZsSGWt4SmU3MyAD1Jy9XeLWJeeYkZGqInUV9qX9vFA1M7Imn6gEmCU/0','24','5','20.00','16.16','1453991616','0','0');");
E_D("replace into `ecs_users_activity` values('24','4498','小龙虾','http://wx.qlogo.cn/mmopen/2KjiaxU8ZEl781ldteHN3QefRJG6pj3muxVdI0bZKLyjNjRSuAyb6x3V7BB0WI7C5crIvvBjEvPqmiaiblicDvM88DGQOeQQKUvZ/0','24','5','20.00','16.53','1453994080','0','0');");
E_D("replace into `ecs_users_activity` values('25','4293','马华泉','http://wx.qlogo.cn/mmopen/2KjiaxU8ZEl5hgUd91Aiagps9jticMlqE5ia3dJjkVDsjBUJL7Y1oqzOwuLqOOHG7nxxBRomeZFVKEN9UCLYicTGG9f3GzW0Gm7Hc/0','24','5','20.00','16.03','1453997770','0','0');");
E_D("replace into `ecs_users_activity` values('26','4739','~知足常乐~吴东国','http://wx.qlogo.cn/mmopen/ib7Efy61IoTBRS4IY49lGmqkretvGzajOIUEXPANl10Cczs3cPbcIH1al98LM6iaT2odcy8fXGSK4EMGlgdG7GAkWfqXqBibVOp/0','24','5','20.00','20.00','1453999210','0','0');");
E_D("replace into `ecs_users_activity` values('27','4740','春明','http://wx.qlogo.cn/mmopen/2KjiaxU8ZEl5hgUd91Aiagph18pqXXQB3tQic7q65Qia2ze0ILibk4T3xLbxBpLMhe7Ucg7NWRMN9MHrqx1Ka35wGMHOAiaqEGN8gp/0','24','5','20.00','15.84','1453999639','0','0');");
E_D("replace into `ecs_users_activity` values('28','4741','玮哥~超级派对CEO','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tvaesBDEgGdA0ZGoQHPstZoJLD2AZ9tJv99p6nwOxodqXiaNib5x2sIlwJ1ysSy6rSozB01mFP8tibF8EoIHubmpF/0','24','5','20.00','18.15','1453999729','0','0');");
E_D("replace into `ecs_users_activity` values('29','4427','家大于天','http://wx.qlogo.cn/mmopen/ib7Efy61IoTDfdjaN2k3ZoCVwiahicUDrTHaw20aWmpiaYF5g8an8lBOtM3ia5BZPiax7XDjkbuxKplWFLTUArYWOTb8h8ewBxqpaL/0','24','5','20.00','15.16','1454000650','0','0');");
E_D("replace into `ecs_users_activity` values('30','4753','芯    碎','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6ulfylfCayZF2yDMybCwUWLWVwjkmicZPWiaGWZqtJrTVvTT6XSNB0dVU2ibsbicHq6HZ1QYz2JmYFPut6ribsMo9I3c/0','24','5','20.00','17.15','1454004326','0','0');");
E_D("replace into `ecs_users_activity` values('31','4587','曾毅','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tMkmiaSrJ0aZ2m0lu7evyFCX9f6ibKT43icKfEwXsLh0XIVm8jiba4czGojMJh2mzwoaZjiawd05U40RhoBgootbOWz/0','24','5','20.00','20.00','1454005194','0','0');");
E_D("replace into `ecs_users_activity` values('32','4448','cc','http://wx.qlogo.cn/mmopen/ib7Efy61IoTCJ1zrNiaxGERYRnbU9cmk8135iaibjXWpGake7wy3OYUH1TzjE9ufcvDp8VMo0ibdTTDZnEs3wp0dOejHic2ZhDw5dx/0','24','5','20.00','15.04','1454011616','0','0');");
E_D("replace into `ecs_users_activity` values('33','4772','yongsen','http://wx.qlogo.cn/mmopen/ZMdxSDafpxQD2AYFER3of5hibVjXibOh9vXDuL0yzcwe84BTtvibJBvZchGewVEqiaeSC9E2MVrX2hUveLJicIlxOog/0','24','5','20.00','17.69','1454023860','0','0');");
E_D("replace into `ecs_users_activity` values('34','4557','毛明祥-艾祥电商','http://wx.qlogo.cn/mmopen/PiajxSqBRaELZCpA8TUobQLP8bH5ic4rSNicxTNVbCUvd1cb4DKbCJC28ZicKz21ou8RPCibNIJjIfAlcBqIEKOwqeg/0','24','5','20.00','20.00','1454028812','0','0');");
E_D("replace into `ecs_users_activity` values('35','4333','临沧慧明科技','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tvaesBDEgGdBCRlkpQM3GM1Ts6e2Vq4Ruhy5F9iahY3csgD09JuMSfh4buj7iaFicTiaHba5JDtoDrwKHxrSnlPwgu/0','24','5','20.00','15.12','1454029036','0','0');");
E_D("replace into `ecs_users_activity` values('36','4325','大城','http://wx.qlogo.cn/mmopen/PiajxSqBRaEI86dPcm4EnogIE0piaoVTzUnzsv8cz7WuibRUbfdsLK1KyY2a4SJmmvPMFicDEx8OIHFSJbocIKApsg/0','24','5','20.00','17.73','1454033149','0','0');");
E_D("replace into `ecs_users_activity` values('37','4381','a.吴国硕','http://wx.qlogo.cn/mmopen/PiajxSqBRaEJDV8Il6Sy3Ezp65cLPia5wYicX3CMib2y9icsXtMt7GvZic07dGhgmpGBvIa7rPZA6bbZuP6FXV1uz4GQ/0','24','5','20.00','20.00','1454045638','0','0');");
E_D("replace into `ecs_users_activity` values('38','4781','吾皇万岁','http://wx.qlogo.cn/mmopen/iaJ9CYbic2W6tMkmiaSrJ0aZ4M5MnEyTw2HVA51ia1p4uh33PDaat2LyhswaJ5c7LNGiarhFW1Wx8NIHv4MqsJ0alwTIb9WmpE72U/0','24','5','20.00','18.34','1454053339','0','0');");
E_D("replace into `ecs_users_activity` values('39','4793','读前往后从','http://wx.qlogo.cn/mmopen/MDujI20ZrCUjqjibiammfEzPcibooFOFGBF5e5gdlSpjfFQ5e7tDYQCH8uZsmWvWGLBic0Cn0q5tKbpvt7Twz8MabqfAhXXiaJHicq/0','24','5','20.00','18.70','1454128670','0','0');");
E_D("replace into `ecs_users_activity` values('40','4792','Mr.Alimjohn','http://wx.qlogo.cn/mmopen/2KjiaxU8ZEl5hgUd91AiagpkBgw2AWCHLCepA4KBBkYaHgTInibP0wyuiacnCnLFygGLsYVV5qZSn1zqlALybgjZLEtEicmfJJ8or/0','24','5','20.00','16.91','1454132423','0','0');");

require("../../inc/footer.php");
?>