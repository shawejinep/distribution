<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_sessions`;");
E_C("CREATE TABLE `ecs_sessions` (
  `sesskey` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `expiry` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adminid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `user_name` varchar(60) NOT NULL,
  `user_rank` tinyint(3) NOT NULL,
  `discount` decimal(3,2) NOT NULL,
  `email` varchar(60) NOT NULL,
  `data` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_sessions` values('6bdc9fe9eea7a1695aada1bcc8814bc9','1454173814','0','0','101.226.33.224','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('b14b2f0794baf1260d162587e0a29c3b','1454174109','0','0','123.166.243.135','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('91f3464928c677bacd711d70a229c202','1454175218','0','0','182.92.229.98','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('fea0a102fbe171573e7c25e19380db04','1454175151','0','0','139.129.17.89','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('20b95287dacf6e097b3e96d47f311204','1454174709','0','0','113.117.29.153','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:12:\"groupmessage\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('d603613d37556b8319efbef39d5314cc','1454175218','0','0','101.226.62.82','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('1be15919a8538f79e12903a4cb3fc9a3','1454175218','0','0','182.92.229.98','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('d26b69c24897ac526238ba91e844b94d','1454173737','0','0','123.166.243.135','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('60b2f0f2028d6129c9d174482af0c8d3','1454173699','0','0','51.255.65.89','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('7d534ec5c978fba7a1b599c3cd06ba83','1454173658','0','0','123.125.71.106','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('61ba656f900f10a3298ae73015f901e0','1454173615','0','0','123.125.71.14','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('ac0932b800dd8c8a99944e62bfc74a9e','1454173563','0','0','51.255.65.67','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('00d8ff8a723382433986b24e579a4015','1454174465','0','0','123.166.243.135','0','0','0.00','0','a:0:{}');");
E_D("replace into `ecs_sessions` values('c043f7dfd6dabf8a5b5feb8e74108d67','1454174062','0','0','117.185.27.103','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('d1b9c45a982ba3c4f0b295af14c23de0','1454174634','0','0','220.181.108.140','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('6e0f255b6ef705018bf37a3aebe0dc1d','1454173820','0','0','112.64.235.248','0','0','0.00','0','a:0:{}');");
E_D("replace into `ecs_sessions` values('ccd2b02a44a52abcd76dc8d3aa55ee0c','1454173820','0','0','180.153.214.192','0','0','0.00','0','a:0:{}');");
E_D("replace into `ecs_sessions` values('3502f708a953ea94a542710304ba638e','1454173849','0','0','180.153.206.24','0','0','0.00','0','a:0:{}');");
E_D("replace into `ecs_sessions` values('bdbba4fd88776292a6fca0584a0e7762','1454174085','4184','0','60.180.26.120','tianxin4184','1','1.00','0','a:6:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:13:\"singlemessage\";s:10:\"login_fail\";i:0;s:9:\"wechat_id\";s:28:\"oJrn5ss1_WF4iB9KckanSSpduvYM\";s:9:\"last_time\";s:10:\"1454089198\";s:7:\"last_ip\";s:13:\"60.180.25.104\";}');");
E_D("replace into `ecs_sessions` values('9f91bc5b125b078d4680c05ae7ff7892','1454174062','0','0','140.207.185.125','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('e9472a803e683de3bf69a6eb6cd2fb01','1454174063','0','0','112.64.235.249','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:13:\"singlemessage\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('8e9e96bf8d60443fc90c2b1b0e3e94d0','1454175152','0','0','139.129.17.89','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");
E_D("replace into `ecs_sessions` values('3e3f9c0cfc21042f309dad8688b17159','1454173484','0','0','51.255.65.87','0','0','1.00','0','a:3:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;}');");

require("../../inc/footer.php");
?>