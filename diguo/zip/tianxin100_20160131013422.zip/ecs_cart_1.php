<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_cart`;");
E_C("CREATE TABLE `ecs_cart` (
  `rec_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `session_id` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `goods_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `goods_sn` varchar(60) NOT NULL DEFAULT '',
  `product_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `group_id` varchar(255) NOT NULL,
  `goods_name` varchar(120) NOT NULL DEFAULT '',
  `market_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `goods_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `goods_number` smallint(5) unsigned NOT NULL DEFAULT '0',
  `goods_attr` text NOT NULL,
  `is_real` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `extension_code` varchar(30) NOT NULL DEFAULT '',
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rec_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_gift` smallint(5) unsigned NOT NULL DEFAULT '0',
  `is_shipping` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `can_handsel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `goods_attr_id` varchar(255) NOT NULL DEFAULT '',
  `fencheng` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rec_id`),
  KEY `session_id` (`session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4396 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_cart` values('4386','0','79223338feb35019bb2561327939bfda','109','ECS000109','0','','兰芝多效四合一泡沫洗面奶180ml','205.00','129.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4387','4700','2b5180815a1c2f666eb86824a419b414','123','ECS000123','0','','迪奥红毒女士香水EDT 50ml','550.80','400.00','1','','1','','0','0','0','0','0','','0');");
E_D("replace into `ecs_cart` values('4383','4333','737dbaaf6e973b528857445e2b00b74c','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','15.12','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4388','0','be6cc107864d48374e13a9c831141b34','109','ECS000109','0','','兰芝多效四合一泡沫洗面奶180ml','205.00','129.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4380','4769','d91cdbae6b4efc33151e175f897aa1a5','109','ECS000109','0','','兰芝多效四合一泡沫洗面奶180ml','205.00','129.00','2','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4373','4751','72c708e1f2f8d565d2206b02c31735a3','119','ECS000119','0','','蓓丽柔和泡沫洁面膏125ml','630.00','320.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4374','4756','616bd8731c482d994284d3862ef36608','120','ECS000120','0','','曼秀雷敦洁清爽卸妆洁面泡200ml','120.00','45.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4377','4448','78e10b0e0d67b0b6d144f8023994ed18','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','16.94','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4378','0','8a792616b76b31f1456d0d87e5d26e21','17','ECS000017','0','','娇韵诗超V型纤容紧致瘦脸面膜75ml','396.00','275.00','1','','1','','0','0','0','0','0','','100');");
E_D("replace into `ecs_cart` values('4379','0','1d5d6a284c917d14ce3a847752d9d500','9','ECS000009','0','','雅诗兰黛第六代特润精华露50ml','950.00','669.00','2','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4353','4674','bd104dc293a0411bd1645d4b778878ea','17','ECS000017','0','','娇韵诗超V型纤容紧致瘦脸面膜75ml','396.00','275.00','1','','1','','0','0','0','0','0','','100');");
E_D("replace into `ecs_cart` values('4372','4587','ef805e05d77575915b7d1089979a29aa','119','ECS000119','0','','蓓丽柔和泡沫洁面膏125ml','630.00','320.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4371','4587','ef805e05d77575915b7d1089979a29aa','120','ECS000120','0','','曼秀雷敦洁清爽卸妆洁面泡200ml','120.00','45.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4370','4741','7def26ccc88af4e71814c79065d88878','123','ECS000123','0','','迪奥红毒女士香水EDT 50ml','550.80','400.00','1','','1','','0','0','0','0','0','','0');");
E_D("replace into `ecs_cart` values('4369','4344','b67ba8d1426b7570785c3ad4d8529e1d','17','ECS000017','0','','娇韵诗超V型纤容紧致瘦脸面膜75ml','396.00','275.00','1','','1','','0','0','0','0','0','','100');");
E_D("replace into `ecs_cart` values('4366','4498','20cbea0ce419799cfe2ca8ef4e8ba838','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','16.53','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4367','4739','a3e9ba0a931aa4778855cca03e87abd3','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','20.00','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4368','4740','08f48e15fbfe1895afe267f0d92304db','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','15.84','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4362','4729','d169d37c351424df5845419568f251fc','109','ECS000109','0','','兰芝多效四合一泡沫洗面奶180ml','205.00','129.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4360','4404','2ebbe92df068853fa0a7abe598b6d1be','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','18.82','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4358','4722','f25d29b07cd44ea23f84b6706286f62a','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','20.00','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4361','4725','c1b0ce49e34bcb1481c9f9f2115da511','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','18.80','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4356','4225','ed77fe59fc3e91c996a464bb77590a2a','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','18.02','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4355','4674','bd104dc293a0411bd1645d4b778878ea','1','ECS000000','0','','希思黎轻柔护肤西柚柔肤水250ml','620.00','399.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4354','4674','bd104dc293a0411bd1645d4b778878ea','115','ECS000115','0','','DHC橄榄滋养皂90g','110.00','65.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4352','4674','cc44885fc1b6c67735222dfbcc29b190','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','18.82','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4351','4510','d068093d550ea705586b3fcf6953e9ef','93','ECS000093','0','','姗娜豆乳美肌卸妆洗面膏150g','95.00','69.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4350','4510','d068093d550ea705586b3fcf6953e9ef','123','ECS000123','0','','迪奥红毒女士香水EDT 50ml','550.80','400.00','6','','1','','0','0','0','0','0','','0');");
E_D("replace into `ecs_cart` values('4349','4713','1abe8229981c9d256cd40d15d939c6f9','123','ECS000123','0','','迪奥红毒女士香水EDT 50ml','550.80','400.00','1','','1','','0','0','0','0','0','','0');");
E_D("replace into `ecs_cart` values('4348','4298','877ac863416afab3f7dd0fe1023b98ba','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','17.67','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4347','4680','343a7830e90d78c1a7174704a92b1cd6','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','20.00','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4346','4703','4f348afb1cbd8ac1bb878d2e4441af3e','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','17.72','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4345','4651','2ef6fa3c02e78752f185307a4b807ffd','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','18.11','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4344','4696','4963840916639ff4795b6a6432235300','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','15.68','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4343','4272','0935c502ff6660c54786ffff9a95fb62','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','18.05','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4342','4373','7f1fc7894e32bf01422c91b3c940cd77','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','20.00','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4340','4246','ad054bc7412a7811bb410d99af0a052c','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','17.68','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4339','4246','830e48d8a110ffa7af68e2899fa8fe67','5','ECS000005','0','','索爱原装M2卡读卡器','24.00','20.00','1','','1','','0','5','0','0','0','','');");
E_D("replace into `ecs_cart` values('4337','4652','6b6777d820b29e43c12cc2b1373cb73b','112','ECS000112','0','','欧莱雅清润抗油洁面膏100ml','85.00','49.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4336','4652','6b6777d820b29e43c12cc2b1373cb73b','17','ECS000017','0','','娇韵诗超V型纤容紧致瘦脸面膜75ml','396.00','275.00','1','','1','','0','0','0','0','0','','100');");
E_D("replace into `ecs_cart` values('4389','4786','08dc4fc791b7772bcafaffdcda89938d','123','ECS000123','0','','迪奥红毒女士香水EDT 50ml','550.80','400.00','1','','1','','0','0','0','0','0','','0');");
E_D("replace into `ecs_cart` values('4390','0','437a2b08cb6de03c3bfaaccca84466c9','112','ECS000112','0','','欧莱雅清润抗油洁面膏100ml','85.00','49.00','1','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4391','0','ad2259dabb3792ca1fdd682149ab4cd6','112','ECS000112','0','','欧莱雅清润抗油洁面膏100ml','85.00','49.00','3','','1','','0','0','0','0','0','','');");
E_D("replace into `ecs_cart` values('4394','4795','bb7d3908e2c48ea0ab20da06671ee7a2','163','12345','0','','精品男袜','20.00','15.80','1','颜色:36[12] \n','1','','0','0','0','0','0','351','0');");
E_D("replace into `ecs_cart` values('4395','4725','5544e3368d6dafd0e16254237d5102ba','165','ECS000165','0','','微信商城分销系统|ecshop分销|商城分销源码|微商城分销|技术支持','0.00','0.00','1','','1','','0','0','0','0','0','','0');");

require("../../inc/footer.php");
?>