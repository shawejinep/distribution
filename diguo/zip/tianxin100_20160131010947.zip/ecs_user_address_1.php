<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_user_address`;");
E_C("CREATE TABLE `ecs_user_address` (
  `address_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `address_name` varchar(50) NOT NULL DEFAULT '',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `consignee` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `country` smallint(5) NOT NULL DEFAULT '0',
  `province` smallint(5) NOT NULL DEFAULT '0',
  `city` smallint(5) NOT NULL DEFAULT '0',
  `district` smallint(5) NOT NULL DEFAULT '0',
  `address` varchar(120) NOT NULL DEFAULT '',
  `zipcode` varchar(60) NOT NULL DEFAULT '',
  `tel` varchar(60) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  `sign_building` varchar(120) NOT NULL DEFAULT '',
  `best_time` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`address_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1447 DEFAULT CHARSET=utf8");
E_D("replace into `ecs_user_address` values('1307','','4177','1111','','1','4','55','540','1111','','18638360405','','','');");
E_D("replace into `ecs_user_address` values('1308','','4176','1111','','1','3','37','409','11111','','18638360405','','','');");
E_D("replace into `ecs_user_address` values('1309','','4185','奖励','','1','13','185','1581','看了','','11111111111','','','');");
E_D("replace into `ecs_user_address` values('1310','','4186','中国','','1','5','65','628','啊啊啊啊啊爸爸啊','','13122225555','','','');");
E_D("replace into `ecs_user_address` values('1311','','4202','陈','','1','4','56','548','开发区','','18059388111','','','');");
E_D("replace into `ecs_user_address` values('1312','','4204','田婷','','1','6','81','755','街道办','','15807490095','','','');");
E_D("replace into `ecs_user_address` values('1313','','4210','我我我','','1','2','52','500','我的地址','','13008855666','','','');");
E_D("replace into `ecs_user_address` values('1314','','4210','我我我','','1','2','52','500','我的地址','','13008855666','','','');");
E_D("replace into `ecs_user_address` values('1315','','4227','张三丰','11226754@qq.com','1','2','52','500','测试','123456','123456789','','','');");
E_D("replace into `ecs_user_address` values('1316','','4245','杨','','1','6','77','707','南新路','','13316578142','','','');");
E_D("replace into `ecs_user_address` values('1317','','4251','刚刚空','','1','2','52','500','滚滚滚古古怪怪','','13777777777','','','');");
E_D("replace into `ecs_user_address` values('1318','','4251','刚刚空','','1','2','52','500','滚滚滚古古怪怪','','13777777777','','','');");
E_D("replace into `ecs_user_address` values('1319','','4201','测试','','1','6','76','695','测试','','1321','','','');");
E_D("replace into `ecs_user_address` values('1320','','4264','景德镇','','1','2','52','501','丰富的事实','','13122335433','','','');");
E_D("replace into `ecs_user_address` values('1321','','4285','就够','','1','5','66','633','呵呵','','18085673802','','','');");
E_D("replace into `ecs_user_address` values('1322','','4286','今天是','','1','6','86','787','金鸡湖TM魔图','','18088858669','','','');");
E_D("replace into `ecs_user_address` values('1323','','4268','锋锐','','1','22','289','2386','万达广场','','13255522563','','','');");
E_D("replace into `ecs_user_address` values('1324','','4274','时间','','1','2','52','501','简直就是加时赛结束时','','13987654321','','','');");
E_D("replace into `ecs_user_address` values('1325','','4310','逯江坤','','1','6','80','748','突击啦啦啦啦啦','','2285558','','','');");
E_D("replace into `ecs_user_address` values('1326','','4193','测试','','1','22','293','2420','测试','','14763385634','','','');");
E_D("replace into `ecs_user_address` values('1327','','4214','斤斤计较了','','1','11','154','1307','图图图图图图','','12345678912','','','');");
E_D("replace into `ecs_user_address` values('1328','','4181','杨磊','','1','4','55','543','法规和机会','','15398158913','','','');");
E_D("replace into `ecs_user_address` values('1329','','4318','在于我们','','1','5','62','604','爸爸啊','','11223334566','','','');");
E_D("replace into `ecs_user_address` values('1330','','4335','房德','','1','22','293','2420','大学城','','15163383273','','','');");
E_D("replace into `ecs_user_address` values('1333','','4348','g g','','1','2','52','500','t y','','13223232323','','','');");
E_D("replace into `ecs_user_address` values('1334','','4198','测试','','1','2','52','500','测试','','123','','','');");
E_D("replace into `ecs_user_address` values('1335','','4369','123','','1','2','52','500','疯疯癫癫当然','','123815232','','','');");
E_D("replace into `ecs_user_address` values('1336','','4372','中文版','','1','4','56','552','西藏秘密花园酒店123号','','1386667676','','','');");
E_D("replace into `ecs_user_address` values('1337','','4385','秦','','1','2','52','500','西安','','13596356893','','','');");
E_D("replace into `ecs_user_address` values('1338','','4394','拥有','','1','3','37','409','哥哥','','13800013800','','','');");
E_D("replace into `ecs_user_address` values('1339','','4400','推荐了','','1','5','62','605','痛快淋漓健健康康','','15855556','','','');");
E_D("replace into `ecs_user_address` values('1340','','4411','刚刚','','1','4','56','551','上市上市','','146679797','','','');");
E_D("replace into `ecs_user_address` values('1341','','4416','张海强','','1','2','52','500','啦啦啦','','18633739770','','','');");
E_D("replace into `ecs_user_address` values('1342','','4353','张','','1','10','138','1081','高柱','','13933875353','','','');");
E_D("replace into `ecs_user_address` values('1343','','4353','张','','0','0','0','0','','','13933875353','','','');");
E_D("replace into `ecs_user_address` values('1344','','4317','吴维','','1','10','148','1248','东环','','15832699818','','','');");
E_D("replace into `ecs_user_address` values('1345','','4422','554558','','1','4','56','552','OK曲','','18567644611','','','');");
E_D("replace into `ecs_user_address` values('1346','','4437','家姐','','1','6','80','747','33','','13630000000','','','');");
E_D("replace into `ecs_user_address` values('1347','','4431','叶','','1','16','221','1857','金沙江路1658号','','13761209099','','','');");
E_D("replace into `ecs_user_address` values('1348','','4443','111','','1','4','53','519','111','','1111','','','');");
E_D("replace into `ecs_user_address` values('1349','','4211','苟登勇','','1','8','115','1003','榕江县古州北路66号二楼','','135836426','','','');");
E_D("replace into `ecs_user_address` values('1350','','4477','测试','','1','2','52','501','测试测试','','13888888888','','','');");
E_D("replace into `ecs_user_address` values('1351','','4501','Ce','','1','5','65','627','Cs','','13875223508','','','');");
E_D("replace into `ecs_user_address` values('1352','','4396','马华一','','1','3','36','399','中国人民','','134679736899','','','');");
E_D("replace into `ecs_user_address` values('1353','','4526','陈知贤','','1','3','3401','3402','测试','','18130020106','','','');");
E_D("replace into `ecs_user_address` values('1354','','4547','你好','','1','6','79','716','中山','','18955667788','','','');");
E_D("replace into `ecs_user_address` values('1355','','4547','你好','','1','6','79','0','中山','','18955667788','','','');");
E_D("replace into `ecs_user_address` values('1356','','4548','你好','','1','6','80','748','明明知道了啊哈哈','','12345464999','','','');");
E_D("replace into `ecs_user_address` values('1358','','4570','Www','','1','3','41','436','Www ','','1111','','','');");
E_D("replace into `ecs_user_address` values('1359','','4581','楠哥','','1','11','166','1409','楠哥测试','','18137829289','','','');");
E_D("replace into `ecs_user_address` values('1360','','4592','不','','1','5','65','629','灬','','13512345678','','','');");
E_D("replace into `ecs_user_address` values('1361','','4598','12231','','1','2','52','501','35436345','','453345','','','');");
E_D("replace into `ecs_user_address` values('1362','','4508','张三','','1','7','102','906','电脑城','','18255555858','','','');");
E_D("replace into `ecs_user_address` values('1363','','4276','来看看','','1','2','52','500','啦啊','','13800138000','','','');");
E_D("replace into `ecs_user_address` values('1364','','4368','五','','1','3','39','421','池','','112233684','','','');");
E_D("replace into `ecs_user_address` values('1365','','4368','五','','1','3','39','421','池','','112233684','','','');");
E_D("replace into `ecs_user_address` values('1366','','4639','看看','','1','5','65','628','舅舅家','','134876464','','','');");
E_D("replace into `ecs_user_address` values('1367','','4654','ywtetet','','1','6','80','749','hdbdhebhdbd','','1555555555','','','');");
E_D("replace into `ecs_user_address` values('1368','','4655','曾','','1','17','233','1958','贤士二路15号','','18970927500','','','');");
E_D("replace into `ecs_user_address` values('1369','','4657','hyy','','1','6','80','748','yyyyy','','136600666644','','','');");
E_D("replace into `ecs_user_address` values('1370','','4684','李三','','1','3','38','416','葫芦里Hi好','','13800000000','','','');");
E_D("replace into `ecs_user_address` values('1371','','4690','test','','1','2','52','502','对饭否恢复','','12800128000','','','');");
E_D("replace into `ecs_user_address` values('1372','','4696','黄','','1','3','36','398','测试','','13912345678','','','');");
E_D("replace into `ecs_user_address` values('1373','','4231','张雨生','','1','5','65','627','高速','','13658745689','','','');");
E_D("replace into `ecs_user_address` values('1374','','4705','刘先生','','1','6','86','782','江南路111号','','13823888668','','','');");
E_D("replace into `ecs_user_address` values('1375','','4189','郭强','','1','17','242','2047','测试','','10000','','','');");
E_D("replace into `ecs_user_address` values('1376','','4711','周猛','','1','31','383','3233','萧山区建设四路457号','','13388431243','','','');");
E_D("replace into `ecs_user_address` values('1377','','4716','如有需要','','1','4','0','0','了就就请收听回来就115','','18569548748','','','');");
E_D("replace into `ecs_user_address` values('1378','','4716','如有需要','','1','4','53','518','了就就请收听回来就115','','18569548748','','','');");
E_D("replace into `ecs_user_address` values('1379','','4716','如有需要','','1','4','0','0','了就就请收听回来就115','','18569548748','','','');");
E_D("replace into `ecs_user_address` values('1380','','4734','1455','','1','7','103','912','时间久了','','1544453','','','');");
E_D("replace into `ecs_user_address` values('1381','','4742','张磊','','1','27','343','2912','南开区','','18622189952','','','');");
E_D("replace into `ecs_user_address` values('1382','','4743','徐骏杰','','1','3','45','462','佛子领路168号','','18056429686','','','');");
E_D("replace into `ecs_user_address` values('1383','','4751','刘德华','','1','2','52','500','哈哈姐姐','','18766377733','','','');");
E_D("replace into `ecs_user_address` values('1384','','4760','广告','','1','4','55','540','凤飞飞凤飞飞','','15522223333','','','');");
E_D("replace into `ecs_user_address` values('1385','','4763','分分','','1','4','55','539','程晨','','15823225001','','','');");
E_D("replace into `ecs_user_address` values('1386','','4765','你好','','1','24','311','2600','安','','18888888888','','','');");
E_D("replace into `ecs_user_address` values('1387','','4257','我们','','1','2','52','500','你的','','12234455','','','');");
E_D("replace into `ecs_user_address` values('1388','','4179','ggg','','1','4','56','553','覆盖哈哈哈','','18638360405','','','');");
E_D("replace into `ecs_user_address` values('1389','','4331','ddddddd','','1','0','0','0','先休息休息','','11111111111','','','');");
E_D("replace into `ecs_user_address` values('1390','','4866','测试','','1','16','223','1884','测试','','13866666666','','','');");
E_D("replace into `ecs_user_address` values('1391','','4903','hhh','','1','5','62','607','hhh','','13333333333','','','');");
E_D("replace into `ecs_user_address` values('1392','','4466','全桂森','','1','6','76','693','天河区天平架5号空间创意园8-9楼','','13246821387','','','');");
E_D("replace into `ecs_user_address` values('1393','','4199','想改啥','','1','2','52','500','嘎嘎嘎','','188182233666','','','');");
E_D("replace into `ecs_user_address` values('1394','','4225','张三','','1','4','56','553','陈俊杰','','18059632568','','','');");
E_D("replace into `ecs_user_address` values('1395','','4228','测试','','1','6','76','692','嗯','','188183828','','','');");
E_D("replace into `ecs_user_address` values('1396','','4252','哈哈','','1','24','311','2600','酒十路','','18629501510','','','');");
E_D("replace into `ecs_user_address` values('1397','','4262','xiaozhao','','1','9','124','0','jsghsnehj','','13069275262','','','');");
E_D("replace into `ecs_user_address` values('1398','','4236','王祖兴','','1','13','189','1594','11','','15872720707','','','');");
E_D("replace into `ecs_user_address` values('1399','','4284','地方法','','1','6','77','708','才吃个哥','','12452358','','','');");
E_D("replace into `ecs_user_address` values('1400','','4292','符合健康','','1','4','56','551','法国进口','','123456','','','');");
E_D("replace into `ecs_user_address` values('1401','','4294','dhdhdh','','1','2','52','501','dgdhdhdhdd','','13021701121','','','');");
E_D("replace into `ecs_user_address` values('1402','','4296','冯志强','','1','6','91','819','阳江市江城区','','18996300704','','','');");
E_D("replace into `ecs_user_address` values('1403','','4307','w','','1','4','56','551','tyt','','22222','','','');");
E_D("replace into `ecs_user_address` values('1404','','4307','w','','1','4','56','551','tyt','','22222','','','');");
E_D("replace into `ecs_user_address` values('1405','','4307','w','','1','4','56','551','tyt','','22222','','','');");
E_D("replace into `ecs_user_address` values('1406','','4307','w','','1','4','56','551','tyt','','22222','','','');");
E_D("replace into `ecs_user_address` values('1407','','4327','女魔','','1','5','66','633','587588','','156723568956','','','');");
E_D("replace into `ecs_user_address` values('1408','','4192','养老','','1','3','40','426','给 v 姐姐家','','135677776547','','','');");
E_D("replace into `ecs_user_address` values('1409','','4343','肖申克','','1','6','77','705','华强北','','13207976810','','','');");
E_D("replace into `ecs_user_address` values('1410','','4347','元','','1','2','52','502','被清理1¥','','15201592542','','','');");
E_D("replace into `ecs_user_address` values('1411','','4350','啦啦啦','','1','31','383','3236','33号把摸摸摸摸现','','13325121478','','','');");
E_D("replace into `ecs_user_address` values('1412','','4365','谢永飞','','1','16','220','1835','虎踞北路90号，移动大厦6楼','','13913039562','','','');");
E_D("replace into `ecs_user_address` values('1413','','4249','j，l','','1','3','37','409','近李娇','','18502905262','','','');");
E_D("replace into `ecs_user_address` values('1414','','4387','测试','','1','13','193','1611','测试测试测试','','13669081572','','','');");
E_D("replace into `ecs_user_address` values('1415','','4399','聂','','1','14','202','1693','新商城','','18974520905','','','');");
E_D("replace into `ecs_user_address` values('1416','','4403','陈凤剑','','1','2','52','500','警队节奏','','18101410777','','','');");
E_D("replace into `ecs_user_address` values('1417','','4415','王树海','','1','2','52','500','八','','13323260312','','','');");
E_D("replace into `ecs_user_address` values('1418','','4428','陈先生','','1','4','58','562','福隆星城8幢503','','18959815555','','','');");
E_D("replace into `ecs_user_address` values('1419','','4432','欧R','','1','6','76','700','大石','','13723432133','','','');");
E_D("replace into `ecs_user_address` values('1420','','4448','古古怪','','1','4','55','541','ddddddhjffffddssss','','123456789','','','');");
E_D("replace into `ecs_user_address` values('1421','','4467','杨国强','','1','16','222','1877','澄江中路29号','','15366880638','','','');");
E_D("replace into `ecs_user_address` values('1422','','4470','陈璐璐','','1','16','222','1877','江阴澄江中路29号新体育中心C座3楼小鸟天堂','','13626236251','','','');");
E_D("replace into `ecs_user_address` values('1423','','4483','ggggg','','1','3','36','398','hhggggh','','5667444','','','');");
E_D("replace into `ecs_user_address` values('1424','','4493','杨宾','','1','6','77','708','宝安体育馆西侧华美居','','18927448938','','','');");
E_D("replace into `ecs_user_address` values('1425','','4393','湖南帅哥','','1','14','197','1654','你好','','13874885358','','','');");
E_D("replace into `ecs_user_address` values('1426','','4275','小游戏','','1','6','79','718','泪流满面','','13312345345','','','');");
E_D("replace into `ecs_user_address` values('1427','','4529','我们','','1','2','52','506','科技园航丰路','','18612702909','','','');");
E_D("replace into `ecs_user_address` values('1428','','4602','王小姐','','1','6','79','715','东城中信阳光澳元','','13925703391','','','');");
E_D("replace into `ecs_user_address` values('1429','','4569','还回家','','1','6','80','748','白百合','','123456','','','');");
E_D("replace into `ecs_user_address` values('1430','','4506','梅伟','','1','5','65','628','管理好了','','1155855225','','','');");
E_D("replace into `ecs_user_address` values('1431','','4607','ha h h s','','1','2','52','501','哈哈嘎嘎是广告','','416166262','','','');");
E_D("replace into `ecs_user_address` values('1432','','4607','ha h h s','','1','2','52','501','哈哈嘎嘎是广告','','416166262','','','');");
E_D("replace into `ecs_user_address` values('1433','','4619','放放风','','1','2','52','501','这样我想你就不能','','13332343434','','','');");
E_D("replace into `ecs_user_address` values('1434','','4601','饿呀','','1','2','52','501','活得很好','','13377777777','','','');");
E_D("replace into `ecs_user_address` values('1435','','4333','强先生','','1','30','377','3181','139号','','24156523112','','','');");
E_D("replace into `ecs_user_address` values('1436','','4627','成松','','1','6','77','708','西乡前进二路桃源居13栋3单元402','','13145970862','','','');");
E_D("replace into `ecs_user_address` values('1437','','4628','你的人','','1','2','52','501','你是我的世界','','18970331255','','','');");
E_D("replace into `ecs_user_address` values('1438','','4651','g g h h h','','1','3','36','398','f f v h h','','13212341234','','','');");
E_D("replace into `ecs_user_address` values('1439','','4721','万元','','1','2','52','501','北京','','15115115115','','','');");
E_D("replace into `ecs_user_address` values('1440','','4740','123','','1','6','80','748','12','','122','','','');");
E_D("replace into `ecs_user_address` values('1441','','4741','你家里','','1','3','36','399','那具体快乐','','13988889988','','','');");
E_D("replace into `ecs_user_address` values('1442','','4773','1111','','1','5','66','633','哈哈','','15812345678','','','');");
E_D("replace into `ecs_user_address` values('1443','','4700','四大','','1','3','43','454','就饿哦诶大口大口','','13461518198','','','');");
E_D("replace into `ecs_user_address` values('1444','','4670','也是','','1','5','66','633','门口','','13237089912','','','');");
E_D("replace into `ecs_user_address` values('1445','','4794','Kerry','','1','6','77','707','科伟路','','18566236473','','','');");
E_D("replace into `ecs_user_address` values('1446','','4725','hanmeng','','1','22','283','2338','明水','','13805408851','','','');");

require("../../inc/footer.php");
?>